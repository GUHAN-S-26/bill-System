import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';

class AuditLogsScreen extends ConsumerStatefulWidget {
  const AuditLogsScreen({super.key});

  @override
  ConsumerState<AuditLogsScreen> createState() => _AuditLogsScreenState();
}

class _AuditLogsScreenState extends ConsumerState<AuditLogsScreen> {
  String _searchQuery = '';
  String _selectedOwner = 'all';
  String _selectedModule = 'all';

  @override
  Widget build(BuildContext context) {
    final auditLogsAsync = ref.watch(auditLogsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Shankar Shop Audit Trail',
            style: TextStyle(fontWeight: FontWeight.extrabold, fontSize: 16)),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0F172A),
        elevation: 0,
      ),
      body: Column(
        children: [
          // Filter Bar
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: Column(
              children: [
                TextField(
                  onChanged: (val) => setState(() => _searchQuery = val),
                  decoration: InputDecoration(
                    hintText: 'Search audit logs...',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedOwner,
                        decoration: InputDecoration(
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'all', child: Text('All Owners')),
                          DropdownMenuItem(value: 'venkatesh', child: Text('Venkatesh')),
                          DropdownMenuItem(value: 'priya', child: Text('Priya')),
                          DropdownMenuItem(value: 'deepika', child: Text('Deepika')),
                        ],
                        onChanged: (val) => setState(() => _selectedOwner = val!),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedModule,
                        decoration: InputDecoration(
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'all', child: Text('All Modules')),
                          DropdownMenuItem(
                              value: 'authentication', child: Text('Authentication')),
                          DropdownMenuItem(
                              value: 'shop settings', child: Text('Shop Settings')),
                          DropdownMenuItem(
                              value: 'customers', child: Text('Customers')),
                          DropdownMenuItem(value: 'billing', child: Text('Billing')),
                          DropdownMenuItem(value: 'payments', child: Text('Payments')),
                        ],
                        onChanged: (val) => setState(() => _selectedModule = val!),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Logs List / Table
          Expanded(
            child: auditLogsAsync.when(
              data: (logs) {
                final filtered = logs.where((log) {
                  final matchQuery = log.ownerName
                          .toLowerCase()
                          .contains(_searchQuery.toLowerCase()) ||
                      log.action.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                      log.module.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                      log.recordId.toLowerCase().contains(_searchQuery.toLowerCase());

                  final matchOwner = _selectedOwner == 'all' ||
                      log.ownerName.toLowerCase() == _selectedOwner.toLowerCase();

                  final matchModule = _selectedModule == 'all' ||
                      log.module.toLowerCase() == _selectedModule.toLowerCase();

                  return matchQuery && matchOwner && matchModule;
                }).toList();

                if (filtered.isEmpty) {
                  return const Center(
                      child: Text('No audit logs recorded matching search.'));
                }

                return ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final log = filtered[index];
                    return Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFF1F5F9)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                log.action,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                  color: Color(0xFF581C87),
                                ),
                              ),
                              Text(
                                log.dateTime,
                                style: const TextStyle(
                                    fontSize: 11, color: Colors.grey),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${log.ownerName} (${log.ownerEmail})',
                                style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF0F172A)),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF1F5F9),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  log.module,
                                  style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Record ID: ${log.recordId}',
                            style: const TextStyle(
                                fontSize: 11,
                                fontFamily: 'monospace',
                                color: Colors.grey),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, _) => Center(child: Text('Error: $err')),
            ),
          ),
        ],
      ),
    );
  }
}
