import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  FirestoreService() {
    _db.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  }

  // --- Customers ---
  Stream<List<Customer>> getCustomersStream() {
    return _db.collection('customers').snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) => Customer.fromJson(doc.data()))
          .where((c) => c.status != 'deleted')
          .toList();
    });
  }

  Future<void> saveCustomer(Customer customer) async {
    await _db
        .collection('customers')
        .doc(customer.customerId)
        .set(customer.toJson(), SetOptions(merge: true));
  }

  // --- Bills ---
  Stream<List<Bill>> getBillsStream() {
    return _db.collection('bills').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => Bill.fromJson(doc.data())).toList();
    });
  }

  Future<void> saveBill(Bill bill) async {
    await _db
        .collection('bills')
        .doc(bill.billId)
        .set(bill.toJson(), SetOptions(merge: true));
  }

  // --- Payments ---
  Stream<List<Payment>> getPaymentsStream() {
    return _db.collection('payments').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => Payment.fromJson(doc.data())).toList();
    });
  }

  Future<void> savePayment(Payment payment) async {
    await _db
        .collection('payments')
        .doc(payment.paymentId)
        .set(payment.toJson(), SetOptions(merge: true));
  }

  // --- Shop Settings ---
  Stream<ShopSettings> getSettingsStream() {
    return _db.collection('settings').doc('shop').snapshots().map((doc) {
      if (doc.exists && doc.data() != null) {
        return ShopSettings.fromJson(doc.data()!);
      }
      return ShopSettings(
        shopName: 'Shankar Shop',
        ownerName: 'Venkatesh',
        phone: '+91 98765 43210',
        address: 'Main Street, Market Road',
        upiId: 'shankarshop@upi',
      );
    });
  }

  Future<void> saveSettings(ShopSettings settings) async {
    await _db
        .collection('settings')
        .doc('shop')
        .set(settings.toJson(), SetOptions(merge: true));
  }

  // --- Audit Logs ---
  Stream<List<AuditLog>> getAuditLogsStream() {
    return _db.collection('auditLogs').snapshots().map((snapshot) {
      final list = snapshot.docs.map((doc) => AuditLog.fromJson(doc.data())).toList();
      list.sort((a, b) => b.performedAt.compareTo(a.performedAt));
      return list;
    });
  }

  Future<void> saveAuditLog(AuditLog log) async {
    await _db
        .collection('auditLogs')
        .doc(log.logId)
        .set(log.toJson(), SetOptions(merge: true));
  }

  // --- Active Session ---
  Future<void> updateActiveSession(
      String ownerId, String name, String email) async {
    final now = DateTime.now().toIso8601String();
    final data = {
      'ownerId': ownerId,
      'name': name,
      'email': email,
      'role': 'Owner',
      'loginTime': now,
      'lastActiveTime': now,
    };
    await _db
        .collection('active_sessions')
        .doc(ownerId.toLowerCase())
        .set(data, SetOptions(merge: true));

    await _db
        .collection('active_owner')
        .doc('current')
        .set(data, SetOptions(merge: true));
  }

  Future<void> clearActiveSession(String ownerId) async {
    await _db
        .collection('active_sessions')
        .doc(ownerId.toLowerCase())
        .set({'status': 'logged_out', 'lastActiveTime': DateTime.now().toIso8601String()},
            SetOptions(merge: true));

    await _db.collection('active_owner').doc('current').delete();
  }
}
