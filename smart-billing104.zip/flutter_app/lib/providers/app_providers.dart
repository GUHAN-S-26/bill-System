import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'package:intl/intl.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());
final firestoreServiceProvider =
    Provider<FirestoreService>((ref) => FirestoreService());

final currentOwnerProvider = StateProvider<OwnerProfile?>((ref) => null);

final shopSettingsProvider = StreamProvider<ShopSettings>((ref) {
  final fs = ref.watch(firestoreServiceProvider);
  return fs.getSettingsStream();
});

final customersProvider = StreamProvider<List<Customer>>((ref) {
  final fs = ref.watch(firestoreServiceProvider);
  return fs.getCustomersStream();
});

final billsProvider = StreamProvider<List<Bill>>((ref) {
  final fs = ref.watch(firestoreServiceProvider);
  return fs.getBillsStream();
});

final paymentsProvider = StreamProvider<List<Payment>>((ref) {
  final fs = ref.watch(firestoreServiceProvider);
  return fs.getPaymentsStream();
});

final auditLogsProvider = StreamProvider<List<AuditLog>>((ref) {
  final fs = ref.watch(firestoreServiceProvider);
  return fs.getAuditLogsStream();
});

class AppNotifier extends Notifier<void> {
  @override
  void build() {}

  void logAudit(String module, String action, String recordId) {
    final owner = ref.read(currentOwnerProvider);
    final fs = ref.read(firestoreServiceProvider);
    final now = DateTime.now();
    final formattedDate = DateFormat('dd-MMM-yyyy hh:mm a').format(now);

    final log = AuditLog(
      logId: 'LOG-${now.millisecondsSinceEpoch}',
      ownerName: owner?.displayName ?? 'Venkatesh',
      ownerEmail: owner?.email ?? 'venkatesh@shankarshop.com',
      action: action,
      module: module,
      recordId: recordId,
      dateTime: formattedDate,
      performedBy: owner?.displayName ?? 'Venkatesh',
      performedAt: now.toIso8601String(),
    );

    fs.saveAuditLog(log);
  }
}

final appNotifierProvider = NotifierProvider<AppNotifier, void>(AppNotifier.new);
