import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../models/models.dart';

class BillingScreen extends ConsumerStatefulWidget {
  const BillingScreen({super.key});

  @override
  ConsumerState<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends ConsumerState<BillingScreen> {
  String? _selectedCustomerId;
  final _amountController = TextEditingController();

  void _createBill(List<Customer> customers) async {
    if (_selectedCustomerId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a customer first')),
      );
      return;
    }

    final selectedCustomer = customers.firstWhere(
      (c) => c.customerId == _selectedCustomerId,
      orElse: () => Customer(
        customerId: '',
        customerName: 'Unknown',
        phone: '',
        address: '',
        groupId: '',
        openingBalance: 0,
        currentBalance: 0,
        status: 'active',
        createdAt: '',
        updatedAt: '',
      ),
    );

    if (selectedCustomer.customerId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selected customer is invalid')),
      );
      return;
    }

    final amount = double.tryParse(_amountController.text) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid bill amount')),
      );
      return;
    }

    final billId = 'BIL-${DateTime.now().millisecondsSinceEpoch}';
    final billNumber = '${DateTime.now().millisecondsSinceEpoch}'.substring(6);

    final bill = Bill(
      billId: billId,
      billNumber: billNumber,
      customerId: selectedCustomer.customerId,
      customerName: selectedCustomer.customerName,
      items: [
        BillItem(
          id: '1',
          name: 'Grocery / Retail Items',
          quantity: 1,
          rate: amount,
          total: amount,
        )
      ],
      subtotal: amount,
      paidAmount: 0,
      balance: amount,
      paymentStatus: 'Pending',
      billDate: DateTime.now().toIso8601String(),
      notes: 'Quick Bill',
    );

    // Save Bill
    await ref.read(firestoreServiceProvider).saveBill(bill);

    // Update Customer Balance
    final updatedCustomer = Customer(
      customerId: selectedCustomer.customerId,
      customerName: selectedCustomer.customerName,
      phone: selectedCustomer.phone,
      address: selectedCustomer.address,
      groupId: selectedCustomer.groupId,
      openingBalance: selectedCustomer.openingBalance,
      currentBalance: selectedCustomer.currentBalance + amount,
      status: selectedCustomer.status,
      createdAt: selectedCustomer.createdAt,
      updatedAt: DateTime.now().toIso8601String(),
    );
    await ref.read(firestoreServiceProvider).saveCustomer(updatedCustomer);

    // Log Audit
    ref.read(appNotifierProvider.notifier).logAudit('Billing', 'Created Bill', billId);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bill #$billNumber generated successfully!')),
      );
      setState(() {
        _amountController.clear();
        _selectedCustomerId = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final customersAsync = ref.watch(customersProvider);
    final customersList = customersAsync.value ?? [];

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Quick Bill Counter',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 16),

            // Select Customer
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFF1F5F9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('1. Select Customer',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 10),
                  customersAsync.when(
                    data: (customers) {
                      final hasMatchingValue = _selectedCustomerId != null &&
                          customers.any((c) => c.customerId == _selectedCustomerId);
                      final dropdownValue = hasMatchingValue ? _selectedCustomerId : null;

                      return DropdownButtonFormField<String>(
                        value: dropdownValue,
                        hint: const Text('Choose customer...'),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                        ),
                        items: customers.map((c) {
                          return DropdownMenuItem<String>(
                            value: c.customerId,
                            child: Text('${c.customerName} (Due: ₹${c.currentBalance.toStringAsFixed(2)})'),
                          );
                        }).toList(),
                        onChanged: (val) => setState(() => _selectedCustomerId = val),
                      );
                    },
                    loading: () => const LinearProgressIndicator(),
                    error: (_, __) => const Text('Error loading customers'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Bill Amount Input
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFF1F5F9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('2. Enter Total Amount (₹)',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _amountController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w800),
                    decoration: InputDecoration(
                      prefixText: '₹ ',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            ElevatedButton.icon(
              onPressed: () => _createBill(customersList),
              icon: const Icon(Icons.print_rounded),
              label: const Text('Generate Bill & Print',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF15803D),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
