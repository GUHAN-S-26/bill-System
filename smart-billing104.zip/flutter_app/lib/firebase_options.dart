import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with Firebase.initializeApp
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        return web;
      default:
        return web;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAUt063yfAHZHzNsC_GmgNEIpmYTeUAkDw',
    appId: '1:852583453640:web:ebd2d64040639ed921e6fd',
    messagingSenderId: '852583453640',
    projectId: 'smart-billing-system-88317',
    authDomain: 'smart-billing-system-88317.firebaseapp.com',
    storageBucket: 'smart-billing-system-88317.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAUt063yfAHZHzNsC_GmgNEIpmYTeUAkDw',
    appId: '1:852583453640:android:ebd2d64040639ed921e6fd',
    messagingSenderId: '852583453640',
    projectId: 'smart-billing-system-88317',
    authDomain: 'smart-billing-system-88317.firebaseapp.com',
    storageBucket: 'smart-billing-system-88317.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAUt063yfAHZHzNsC_GmgNEIpmYTeUAkDw',
    appId: '1:852583453640:ios:ebd2d64040639ed921e6fd',
    messagingSenderId: '852583453640',
    projectId: 'smart-billing-system-88317',
    authDomain: 'smart-billing-system-88317.firebaseapp.com',
    storageBucket: 'smart-billing-system-88317.firebasestorage.app',
  );

  static const FirebaseOptions macos = ios;
  static const FirebaseOptions windows = web;
}
