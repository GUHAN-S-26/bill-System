package com.shankarshop.smart_billing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
