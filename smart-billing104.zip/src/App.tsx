import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { BottomNav, TabType } from './components/BottomNav';
import { DashboardView } from './components/dashboard/DashboardView';
import { CustomerListView } from './components/customers/CustomerListView';
import { CustomerDetailView } from './components/customers/CustomerDetailView';
import { AddEditCustomerModal } from './components/customers/AddEditCustomerModal';
import { CreateBillModal } from './components/billing/CreateBillModal';
import { BillHistoryView } from './components/billing/BillHistoryView';
import { BillDetailModal } from './components/billing/BillDetailModal';
import { ReceivePaymentModal } from './components/payments/ReceivePaymentModal';
import { PaymentDetailModal } from './components/payments/PaymentDetailModal';
import { ReportsView } from './components/reports/ReportsView';
import { GroupManagementModal } from './components/groups/GroupManagementModal';
import { BackupSyncView } from './components/backup/BackupSyncView';
import { SettingsView } from './components/settings/SettingsView';
import { AuditLogModal } from './components/settings/AuditLogModal';
import { QuickActionModal } from './components/QuickActionModal';
import { LoginView } from './components/auth/LoginView';
import { Customer, Bill, Payment } from './types';

const AppContent: React.FC = () => {
  const { isAuthenticated, logout } = useApp();

  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  // Overlay Full Views
  const [showBackupSync, setShowBackupSync] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Modals
  const [showFabModal, setShowFabModal] = useState(false);
  const [showCreateBillModal, setShowCreateBillModal] = useState(false);
  const [billModalCustomer, setBillModalCustomer] = useState<Customer | null>(null);

  const [showReceivePaymentModal, setShowReceivePaymentModal] = useState(false);
  const [paymentModalCustomer, setPaymentModalCustomer] = useState<Customer | null>(null);

  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);

  const [selectedBillForDetail, setSelectedBillForDetail] = useState<Bill | null>(null);
  const [selectedPaymentForDetail, setSelectedPaymentForDetail] = useState<Payment | null>(null);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [showAuditLogModal, setShowAuditLogModal] = useState(false);

  if (!isAuthenticated) {
    return <LoginView />;
  }

  // Handle Quick Action Triggers
  const handleOpenCreateBill = (customer?: Customer | null) => {
    setBillModalCustomer(customer || null);
    setShowCreateBillModal(true);
  };

  const handleOpenReceivePayment = (customer?: Customer | null) => {
    setPaymentModalCustomer(customer || null);
    setShowReceivePaymentModal(true);
  };

  const handleOpenAddCustomer = (customer?: Customer | null) => {
    setCustomerToEdit(customer || null);
    setShowAddCustomerModal(true);
  };

  const handleSelectCustomer = (customerId: string) => {
    setSelectedCustomerId(customerId);
    setActiveTab('customers');
    setShowSettings(false);
    setShowBackupSync(false);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900 pb-16">
      {/* Sticky Top Header */}
      <Navbar
        onOpenSettings={() => {
          setShowSettings(true);
          setShowBackupSync(false);
        }}
        onOpenBackupSync={() => {
          setShowBackupSync(true);
          setShowSettings(false);
        }}
      />

      {/* Main Container */}
      <main className="max-w-4xl mx-auto pt-2">
        {showSettings ? (
          <SettingsView
            onBack={() => setShowSettings(false)}
            onOpenAuditLogs={() => setShowAuditLogModal(true)}
            onLogout={() => {
              logout();
              setShowSettings(false);
            }}
          />
        ) : showBackupSync ? (
          <BackupSyncView onBack={() => setShowBackupSync(false)} />
        ) : (
          <>
            {activeTab === 'home' && (
              <DashboardView
                onOpenCreateBill={() => handleOpenCreateBill(null)}
                onOpenReceivePayment={() => handleOpenReceivePayment(null)}
                onSelectCustomer={handleSelectCustomer}
                onViewAllTransactions={() => setActiveTab('billing')}
                onOpenBillDetail={(bill) => setSelectedBillForDetail(bill)}
                onOpenPaymentDetail={(payment) => setSelectedPaymentForDetail(payment)}
              />
            )}

            {activeTab === 'customers' && (
              <>
                {selectedCustomerId ? (
                  <CustomerDetailView
                    customerId={selectedCustomerId}
                    onBack={() => setSelectedCustomerId(null)}
                    onOpenCreateBill={(c) => handleOpenCreateBill(c)}
                    onOpenReceivePayment={(c) => handleOpenReceivePayment(c)}
                    onOpenEditCustomer={(c) => handleOpenAddCustomer(c)}
                    onOpenBillDetail={(b) => setSelectedBillForDetail(b)}
                    onOpenPaymentDetail={(p) => setSelectedPaymentForDetail(p)}
                  />
                ) : (
                  <CustomerListView
                    onSelectCustomer={handleSelectCustomer}
                    onOpenAddCustomer={() => handleOpenAddCustomer(null)}
                    onOpenCreateBillForCustomer={(c) => handleOpenCreateBill(c)}
                    onOpenReceivePaymentForCustomer={(c) => handleOpenReceivePayment(c)}
                    onOpenManageGroups={() => setShowGroupModal(true)}
                  />
                )}
              </>
            )}

            {activeTab === 'billing' && (
              <BillHistoryView
                onOpenCreateBill={() => handleOpenCreateBill(null)}
                onOpenBillDetail={(bill) => setSelectedBillForDetail(bill)}
                onOpenPaymentDetail={(payment) => setSelectedPaymentForDetail(payment)}
              />
            )}

            {activeTab === 'reports' && <ReportsView />}
          </>
        )}
      </main>

      {/* Persistent Bottom Tab Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setShowSettings(false);
          setShowBackupSync(false);
          if (tab !== 'customers') setSelectedCustomerId(null);
        }}
        onOpenFab={() => setShowFabModal(true)}
      />

      {/* Quick Action FAB Modal */}
      <QuickActionModal
        isOpen={showFabModal}
        onClose={() => setShowFabModal(false)}
        onOpenCreateBill={() => handleOpenCreateBill(null)}
        onOpenReceivePayment={() => handleOpenReceivePayment(null)}
        onOpenAddCustomer={() => handleOpenAddCustomer(null)}
        onOpenManageGroups={() => setShowGroupModal(true)}
      />

      {/* Fast Billing Modal */}
      <CreateBillModal
        isOpen={showCreateBillModal}
        onClose={() => setShowCreateBillModal(false)}
        preSelectedCustomer={billModalCustomer}
        onBillCreated={(newBill) => {
          setSelectedBillForDetail(newBill);
        }}
      />

      {/* Receive Payment Modal */}
      <ReceivePaymentModal
        isOpen={showReceivePaymentModal}
        onClose={() => setShowReceivePaymentModal(false)}
        preSelectedCustomer={paymentModalCustomer}
      />

      {/* Add / Edit Customer Modal */}
      <AddEditCustomerModal
        isOpen={showAddCustomerModal}
        onClose={() => {
          setShowAddCustomerModal(false);
          setCustomerToEdit(null);
        }}
        customerToEdit={customerToEdit}
        onCustomerSaved={(cust) => {
          setSelectedCustomerId(cust.customerId);
          setActiveTab('customers');
        }}
      />

      {/* Bill Detail / Receipt Modal */}
      <BillDetailModal
        bill={selectedBillForDetail}
        onClose={() => setSelectedBillForDetail(null)}
      />

      {/* Payment Detail / Receipt Modal */}
      <PaymentDetailModal
        payment={selectedPaymentForDetail}
        onClose={() => setSelectedPaymentForDetail(null)}
      />

      {/* Group Management Modal */}
      <GroupManagementModal
        isOpen={showGroupModal}
        onClose={() => setShowGroupModal(false)}
      />

      {/* Audit Log Modal */}
      <AuditLogModal
        isOpen={showAuditLogModal}
        onClose={() => setShowAuditLogModal(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
