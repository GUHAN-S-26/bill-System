import { Customer, Bill, Payment, ShopSettings } from '../types';

export const exportToCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      row
        .map((field) => {
          const stringVal = String(field ?? '');
          return `"${stringVal.replace(/"/g, '""')}"`;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportFullShopBackupJSON = (
  settings: ShopSettings,
  customers: Customer[],
  bills: Bill[],
  payments: Payment[]
) => {
  const backupData = {
    exportDate: new Date().toISOString(),
    version: '1.0',
    settings,
    customers,
    bills,
    payments,
  };

  const jsonString = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `SmartBilling_Backup_${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const triggerGoogleSheetsSync = async (
  webhookUrl: string,
  payload: any
): Promise<{ success: boolean; message: string }> => {
  if (!webhookUrl || !webhookUrl.startsWith('http')) {
    // Simulated background sync delay
    await new Promise((resolve) => setTimeout(resolve, 800));
    return {
      success: true,
      message: 'Simulated sync complete. Data mirrored locally.',
    };
  }

  try {
    const res = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      return { success: true, message: 'Google Sheets sync successful!' };
    } else {
      return { success: false, message: `Sync failed with status ${res.status}` };
    }
  } catch (err: any) {
    return { success: false, message: err.message || 'Network error during Sheets sync.' };
  }
};
