import { Customer, CustomerGroup, Bill, Payment, ShopSettings, User, AuditLog, SyncQueueItem } from '../types';
import { INITIAL_CUSTOMERS, INITIAL_GROUPS, INITIAL_BILLS, INITIAL_PAYMENTS, INITIAL_SHOP_SETTINGS, INITIAL_USER, INITIAL_AUDIT_LOGS } from './seedData';

const KEYS = {
  SETTINGS: 'smart_billing_settings_v1',
  USER: 'smart_billing_user_v1',
  GROUPS: 'smart_billing_groups_v1',
  CUSTOMERS: 'smart_billing_customers_v1',
  BILLS: 'smart_billing_bills_v1',
  PAYMENTS: 'smart_billing_payments_v1',
  AUDIT_LOGS: 'smart_billing_audit_logs_v1',
  SYNC_QUEUE: 'smart_billing_sync_queue_v1',
  IS_ONLINE: 'smart_billing_is_online_v1',
};

export const getStoredSettings = (): ShopSettings => {
  const data = localStorage.getItem(KEYS.SETTINGS);
  return data ? JSON.parse(data) : INITIAL_SHOP_SETTINGS;
};

export const saveStoredSettings = (settings: ShopSettings) => {
  localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
};

export const getStoredUser = (): User => {
  const data = localStorage.getItem(KEYS.USER);
  return data ? JSON.parse(data) : INITIAL_USER;
};

export const saveStoredUser = (user: User) => {
  localStorage.setItem(KEYS.USER, JSON.stringify(user));
};

export const getStoredGroups = (): CustomerGroup[] => {
  const data = localStorage.getItem(KEYS.GROUPS);
  return data ? JSON.parse(data) : INITIAL_GROUPS;
};

export const saveStoredGroups = (groups: CustomerGroup[]) => {
  localStorage.setItem(KEYS.GROUPS, JSON.stringify(groups));
};

export const getStoredCustomers = (): Customer[] => {
  const data = localStorage.getItem(KEYS.CUSTOMERS);
  return data ? JSON.parse(data) : INITIAL_CUSTOMERS;
};

export const saveStoredCustomers = (customers: Customer[]) => {
  localStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customers));
};

export const getStoredBills = (): Bill[] => {
  const data = localStorage.getItem(KEYS.BILLS);
  return data ? JSON.parse(data) : INITIAL_BILLS;
};

export const saveStoredBills = (bills: Bill[]) => {
  localStorage.setItem(KEYS.BILLS, JSON.stringify(bills));
};

export const getStoredPayments = (): Payment[] => {
  const data = localStorage.getItem(KEYS.PAYMENTS);
  return data ? JSON.parse(data) : INITIAL_PAYMENTS;
};

export const saveStoredPayments = (payments: Payment[]) => {
  localStorage.setItem(KEYS.PAYMENTS, JSON.stringify(payments));
};

export const getStoredAuditLogs = (): AuditLog[] => {
  const data = localStorage.getItem(KEYS.AUDIT_LOGS);
  return data ? JSON.parse(data) : INITIAL_AUDIT_LOGS;
};

export const saveStoredAuditLogs = (logs: AuditLog[]) => {
  localStorage.setItem(KEYS.AUDIT_LOGS, JSON.stringify(logs));
};

export const getSyncQueue = (): SyncQueueItem[] => {
  const data = localStorage.getItem(KEYS.SYNC_QUEUE);
  return data ? JSON.parse(data) : [];
};

export const saveSyncQueue = (queue: SyncQueueItem[]) => {
  localStorage.setItem(KEYS.SYNC_QUEUE, JSON.stringify(queue));
};

export const pushToSyncQueue = (action: string, payload: any) => {
  const queue = getSyncQueue();
  const newItem: SyncQueueItem = {
    id: 'SYNC-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
    action,
    payload,
    timestamp: new Date().toISOString(),
  };
  queue.push(newItem);
  saveSyncQueue(queue);
};

export const clearSyncQueue = () => {
  saveSyncQueue([]);
};

export const getOnlineStatus = (): boolean => {
  const val = localStorage.getItem(KEYS.IS_ONLINE);
  return val !== null ? JSON.parse(val) : true;
};

export const saveOnlineStatus = (isOnline: boolean) => {
  localStorage.setItem(KEYS.IS_ONLINE, JSON.stringify(isOnline));
};

// Recalculates customer totalPurchase, totalPaid, and currentBalance based on active bills & payments
export const recalculateCustomerTotals = (
  customer: Customer,
  bills: Bill[],
  payments: Payment[]
): Customer => {
  const activeBills = bills.filter(
    (b) => b.customerId === customer.customerId && !b.isDeleted
  );
  const activePayments = payments.filter(
    (p) => p.customerId === customer.customerId && !p.isDeleted
  );

  const totalPurchase = activeBills.reduce((sum, b) => sum + b.subtotal, 0);
  const billPaid = activeBills.reduce((sum, b) => sum + b.paidAmount, 0);
  const directPaid = activePayments.reduce((sum, p) => sum + p.amount, 0);
  const totalPaid = billPaid + directPaid;

  const currentBalance = customer.openingBalance + totalPurchase - totalPaid;

  return {
    ...customer,
    totalPurchase,
    totalPaid,
    currentBalance,
    updatedAt: new Date().toISOString(),
  };
};

export const resetToSeedData = () => {
  saveStoredSettings(INITIAL_SHOP_SETTINGS);
  saveStoredUser(INITIAL_USER);
  saveStoredGroups(INITIAL_GROUPS);
  saveStoredCustomers(INITIAL_CUSTOMERS);
  saveStoredBills(INITIAL_BILLS);
  saveStoredPayments(INITIAL_PAYMENTS);
  saveStoredAuditLogs(INITIAL_AUDIT_LOGS);
  clearSyncQueue();
  saveOnlineStatus(true);
};
