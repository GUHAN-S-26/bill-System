import { jsPDF } from 'jspdf';
import { Customer, Bill, Payment, ShopSettings, StatementItem } from '../types';

export const generateCustomerStatementPDF = (
  shopSettings: ShopSettings,
  customer: Customer,
  statementItems: StatementItem[]
) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();

  // Header
  doc.setFillColor(16, 185, 129); // Emerald 600
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text(shopSettings.shopName, 14, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('CUSTOMER ACCOUNT STATEMENT', pageWidth - 14, 12, { align: 'right' });
  doc.text(`Generated: ${new Date().toLocaleDateString('en-IN')}`, pageWidth - 14, 18, { align: 'right' });

  let y = 36;

  // Shop Details & Customer Box
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Shop Details:', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${shopSettings.ownerName} | Ph: ${shopSettings.phone}`, 14, y + 5);
  doc.text(shopSettings.address, 14, y + 10);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Customer Info:', pageWidth / 2 + 10, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Name: ${customer.customerName}`, pageWidth / 2 + 10, y + 5);
  doc.text(`Phone: ${customer.phone || 'N/A'} | Group: ${customer.groupName}`, pageWidth / 2 + 10, y + 10);
  doc.text(`Opening Balance: ₹${customer.openingBalance.toLocaleString('en-IN')}`, pageWidth / 2 + 10, y + 15);

  y += 26;

  // Outstanding Summary Box
  doc.setFillColor(241, 245, 249); // slate-100
  doc.roundedRect(14, y, pageWidth - 28, 16, 2, 2, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(`Total Purchases: ₹${customer.totalPurchase.toLocaleString('en-IN')}`, 20, y + 10);
  doc.text(`Total Paid: ₹${customer.totalPaid.toLocaleString('en-IN')}`, 85, y + 10);

  const pendingColor = customer.currentBalance > 0 ? [220, 38, 38] : [16, 185, 129];
  doc.setTextColor(pendingColor[0], pendingColor[1], pendingColor[2]);
  doc.text(`NET OUTSTANDING: ₹${customer.currentBalance.toLocaleString('en-IN')}`, pageWidth - 20, y + 10, { align: 'right' });

  y += 24;

  // Table Headers
  doc.setFillColor(226, 232, 240); // slate-200
  doc.rect(14, y, pageWidth - 28, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);

  doc.text('DATE', 18, y + 5.5);
  doc.text('REF / TYPE', 42, y + 5.5);
  doc.text('DESCRIPTION', 80, y + 5.5);
  doc.text('BILL (DR)', 130, y + 5.5, { align: 'right' });
  doc.text('PAID (CR)', 160, y + 5.5, { align: 'right' });
  doc.text('BALANCE', pageWidth - 18, y + 5.5, { align: 'right' });

  y += 10;

  // Table Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);

  statementItems.forEach((item, index) => {
    if (y > 270) {
      doc.addPage();
      y = 20;
    }

    if (index % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y - 4, pageWidth - 28, 7, 'F');
    }

    const itemDate = new Date(item.date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: '2-digit',
    });

    doc.text(itemDate, 18, y);
    doc.text(item.refNumber, 42, y);

    // Truncate long descriptions
    const desc = item.description.length > 28 ? item.description.substring(0, 26) + '...' : item.description;
    doc.text(desc, 80, y);

    doc.text(item.debit > 0 ? `₹${item.debit.toLocaleString('en-IN')}` : '-', 130, y, { align: 'right' });
    doc.text(item.credit > 0 ? `₹${item.credit.toLocaleString('en-IN')}` : '-', 160, y, { align: 'right' });

    doc.setFont('helvetica', 'bold');
    doc.text(`₹${item.runningBalance.toLocaleString('en-IN')}`, pageWidth - 18, y, { align: 'right' });
    doc.setFont('helvetica', 'normal');

    y += 7;
  });

  // Footer / Signature
  y = Math.max(y + 15, 250);
  if (y > 270) {
    doc.addPage();
    y = 250;
  }

  doc.setDrawColor(203, 213, 225);
  doc.line(14, y, pageWidth - 14, y);

  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('This is a computer generated statement from Smart Billing System.', 14, y + 6);
  doc.text('Authorized Shop Signature', pageWidth - 14, y + 6, { align: 'right' });

  doc.save(`Statement_${customer.customerName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`);
};

export const generateBusinessReportPDF = (
  shopSettings: ShopSettings,
  title: string,
  summaryMetrics: { label: string; value: string }[],
  headers: string[],
  rows: string[][]
) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();

  // Header banner
  doc.setFillColor(16, 185, 129);
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(shopSettings.shopName, 14, 14);

  doc.setFontSize(11);
  doc.text(title.toUpperCase(), pageWidth - 14, 14, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Date: ${new Date().toLocaleDateString('en-IN')}`, pageWidth - 14, 21, { align: 'right' });

  let y = 36;

  // Summary Cards Bar
  if (summaryMetrics.length > 0) {
    const cardWidth = (pageWidth - 28 - (summaryMetrics.length - 1) * 4) / summaryMetrics.length;
    summaryMetrics.forEach((metric, i) => {
      const x = 14 + i * (cardWidth + 4);
      doc.setFillColor(241, 245, 249);
      doc.roundedRect(x, y, cardWidth, 16, 2, 2, 'F');

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(metric.label, x + 4, y + 6);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text(metric.value, x + 4, y + 12);
    });
    y += 24;
  }

  // Table Headers
  doc.setFillColor(226, 232, 240);
  doc.rect(14, y, pageWidth - 28, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const colWidth = (pageWidth - 28) / headers.length;
  headers.forEach((h, idx) => {
    const alignRight = idx === headers.length - 1 || h.toLowerCase().includes('amount') || h.toLowerCase().includes('balance');
    const xPos = alignRight ? 14 + (idx + 1) * colWidth - 4 : 14 + idx * colWidth + 4;
    doc.text(h, xPos, y + 5.5, { align: alignRight ? 'right' : 'left' });
  });

  y += 10;

  // Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);

  rows.forEach((row, rowIndex) => {
    if (y > 270) {
      doc.addPage();
      y = 20;
    }

    if (rowIndex % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, y - 4, pageWidth - 28, 7, 'F');
    }

    row.forEach((cell, colIndex) => {
      const alignRight = colIndex === headers.length - 1 || headers[colIndex].toLowerCase().includes('amount') || headers[colIndex].toLowerCase().includes('balance');
      const xPos = alignRight ? 14 + (colIndex + 1) * colWidth - 4 : 14 + colIndex * colWidth + 4;
      
      const cellText = cell.length > 28 ? cell.substring(0, 25) + '...' : cell;
      doc.text(cellText, xPos, y, { align: alignRight ? 'right' : 'left' });
    });

    y += 7;
  });

  doc.save(`${title.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`);
};
