import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  ShopSettings,
  CustomerGroup,
  Customer,
  Bill,
  Payment,
  AuditLog,
  ActiveOwnerSession,
} from '../types';
import {
  INITIAL_SHOP_SETTINGS,
  INITIAL_GROUPS,
  INITIAL_CUSTOMERS,
  INITIAL_BILLS,
  INITIAL_PAYMENTS,
  INITIAL_AUDIT_LOGS,
} from './seedData';

// Initialize Firebase App
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with specific databaseId if provided
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Collection References
export const collections = {
  settings: collection(db, 'settings'),
  groups: collection(db, 'groups'),
  customers: collection(db, 'customers'),
  bills: collection(db, 'bills'),
  payments: collection(db, 'payments'),
  auditLogs: collection(db, 'auditLogs'),
};

/**
 * Seeds initial structured data into Firestore if collections are empty.
 */
export async function seedFirestoreIfEmpty(): Promise<boolean> {
  try {
    const custSnapshot = await getDocs(collections.customers);
    if (!custSnapshot.empty) {
      console.log('Firestore already contains data.');
      return false;
    }

    console.log('Seeding initial structured sample data into Firestore...');
    const batch = writeBatch(db);

    // 1. Settings
    const settingsDocRef = doc(db, 'settings', 'main');
    batch.set(settingsDocRef, INITIAL_SHOP_SETTINGS);

    // 2. Groups
    INITIAL_GROUPS.forEach((group) => {
      const gRef = doc(db, 'groups', group.groupId);
      batch.set(gRef, group);
    });

    // 3. Customers
    INITIAL_CUSTOMERS.forEach((customer) => {
      const cRef = doc(db, 'customers', customer.customerId);
      batch.set(cRef, customer);
    });

    // 4. Bills
    INITIAL_BILLS.forEach((bill) => {
      const bRef = doc(db, 'bills', bill.billId);
      batch.set(bRef, bill);
    });

    // 5. Payments
    INITIAL_PAYMENTS.forEach((payment) => {
      const pRef = doc(db, 'payments', payment.paymentId);
      batch.set(pRef, payment);
    });

    // 6. Audit Logs
    INITIAL_AUDIT_LOGS.forEach((log) => {
      const lRef = doc(db, 'auditLogs', log.logId);
      batch.set(lRef, log);
    });

    await batch.commit();
    console.log('Firestore sample data successfully seeded!');
    return true;
  } catch (err) {
    console.error('Error seeding Firestore sample data:', err);
    return false;
  }
}

// Firestore CRUD Helpers

// --- Settings ---
export async function saveSettingsToFirestore(settings: ShopSettings) {
  try {
    await setDoc(doc(db, 'settings', 'main'), settings, { merge: true });
  } catch (e) {
    console.error('Firestore save settings error:', e);
  }
}

// --- Groups ---
export async function saveGroupToFirestore(group: CustomerGroup) {
  try {
    await setDoc(doc(db, 'groups', group.groupId), group, { merge: true });
  } catch (e) {
    console.error('Firestore save group error:', e);
  }
}

export async function deleteGroupFromFirestore(groupId: string) {
  try {
    await deleteDoc(doc(db, 'groups', groupId));
  } catch (e) {
    console.error('Firestore delete group error:', e);
    throw e;
  }
}

// --- Customers ---
export async function saveCustomerToFirestore(customer: Customer) {
  try {
    await setDoc(doc(db, 'customers', customer.customerId), customer, { merge: true });
  } catch (e) {
    console.error('Firestore save customer error:', e);
    throw e;
  }
}

// --- Bills ---
export async function saveBillToFirestore(bill: Bill) {
  try {
    await setDoc(doc(db, 'bills', bill.billId), bill, { merge: true });
  } catch (e) {
    console.error('Firestore save bill error:', e);
  }
}

// --- Payments ---
export async function savePaymentToFirestore(payment: Payment) {
  try {
    await setDoc(doc(db, 'payments', payment.paymentId), payment, { merge: true });
  } catch (e) {
    console.error('Firestore save payment error:', e);
  }
}

// --- Active Owner Sessions ---
export async function saveActiveOwnerSessionToFirestore(session: ActiveOwnerSession) {
  try {
    const sessionDocRef = doc(db, 'active_sessions', session.ownerId.toLowerCase());
    await setDoc(sessionDocRef, session, { merge: true });

    // Also update current active owner doc in Firestore
    const currentDocRef = doc(db, 'active_owner', 'current');
    await setDoc(currentDocRef, session, { merge: true });
  } catch (e) {
    console.error('Firestore save active session error:', e);
  }
}

export async function clearActiveOwnerSessionInFirestore(username: string) {
  try {
    const sessionDocRef = doc(db, 'active_sessions', username.toLowerCase());
    await setDoc(
      sessionDocRef,
      {
        lastActiveTime: new Date().toISOString(),
        status: 'logged_out',
      },
      { merge: true }
    );

    const currentDocRef = doc(db, 'active_owner', 'current');
    await deleteDoc(currentDocRef);
  } catch (e) {
    console.error('Firestore clear active session error:', e);
  }
}

// --- Audit Logs ---
export async function saveAuditLogToFirestore(log: AuditLog) {
  try {
    await setDoc(doc(db, 'auditLogs', log.logId), log, { merge: true });
  } catch (e) {
    console.error('Firestore save audit log error:', e);
  }
}
