export type PaymentMethod = 'cash' | 'upi' | 'bank_transfer' | 'cheque' | 'credit';

export type UserRole = 'owner' | 'manager' | 'staff';

export interface User {
  userId: string;
  authUid: string;
  name: string;
  username: string;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ShopSettings {
  shopName: string;
  ownerName: string;
  phone: string;
  address: string;
  upiId: string;
  currencySymbol: string;
  defaultGroupId: string;
  ownerUserId: string;
  isSetupComplete: boolean;
  googleSheetsWebhookUrl?: string;
  lastSyncedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerGroup {
  groupId: string;
  groupName: string;
  customerCount: number;
  isSystem: boolean;
  isActive: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  customerId: string;
  customerName: string;
  phone: string;
  groupId: string;
  groupName: string;
  openingBalance: number;
  currentBalance: number;
  totalPurchase: number;
  totalPaid: number;
  remarks: string;
  isActive: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface BillEntry {
  id: string;
  amount: number;
  note: string;
}

export interface Bill {
  billId: string;
  billNumber: string;
  customerId: string;
  customerName: string;
  groupId: string;
  groupName: string;
  entries: BillEntry[];
  subtotal: number;
  paidAmount: number;
  pendingAmount: number;
  paymentMethod: PaymentMethod;
  remarks: string;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface Payment {
  paymentId: string;
  customerId: string;
  customerName: string;
  groupId: string;
  groupName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  remarks: string;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  receivedBy?: string;
  updatedBy?: string;
}

export interface ActiveOwnerSession {
  ownerId: string;
  name: string;
  email: string;
  role: string;
  loginTime: string;
  lastActiveTime: string;
}

export interface AuditLog {
  logId: string;
  ownerName: string;
  ownerEmail: string;
  action: string;
  module: 'Authentication' | 'Shop Settings' | 'Customers' | 'Billing' | 'Payments' | 'Products' | 'Groups' | 'System';
  recordId: string;
  dateTime: string;
  performedBy: string;
  performedAt: string;
  entityType?: string;
  entityId?: string;
  details?: any;
}

export interface StatementItem {
  id: string;
  type: 'opening_balance' | 'bill' | 'payment';
  date: string;
  refNumber: string;
  description: string;
  debit: number; // Bill / purchase (increases balance)
  credit: number; // Payment / paid (decreases balance)
  runningBalance: number;
  rawItem?: Bill | Payment;
}

export interface SyncQueueItem {
  id: string;
  action: string;
  payload: any;
  timestamp: string;
}
