export function getTimestampMs(val: any): number {
  if (val === null || val === undefined) return Date.now();
  if (typeof val === 'number') return val;
  if (typeof val === 'string') {
    const ms = new Date(val).getTime();
    return isNaN(ms) ? Date.now() : ms;
  }
  if (typeof val === 'object') {
    if (typeof val.toDate === 'function') {
      try {
        return val.toDate().getTime();
      } catch {
        // Fallback
      }
    }
    if (typeof val.seconds === 'number') {
      return val.seconds * 1000;
    }
  }
  return Date.now();
}

export function getISODateString(val: any): string {
  try {
    const ms = getTimestampMs(val);
    return new Date(ms).toISOString();
  } catch {
    return new Date().toISOString();
  }
}

export function getYYYYMMDD(val: any): string {
  try {
    return getISODateString(val).slice(0, 10);
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export function getYYYYMM(val: any): string {
  try {
    return getISODateString(val).slice(0, 7);
  } catch {
    return new Date().toISOString().slice(0, 7);
  }
}

export function formatTime(val: any): string {
  try {
    const ms = getTimestampMs(val);
    return new Date(ms).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return 'Just now';
  }
}

export function formatDate(val: any): string {
  try {
    const ms = getTimestampMs(val);
    return new Date(ms).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return 'Today';
  }
}

export function formatTransactionDateTime(val: any): string {
  try {
    const ms = getTimestampMs(val);
    const dateStr = getYYYYMMDD(val);
    const todayStr = getYYYYMMDD(new Date());
    const timeStr = new Date(ms).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    if (dateStr === todayStr) {
      return `Today, ${timeStr}`;
    }
    const formattedDate = new Date(ms).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
    });
    return `${formattedDate}, ${timeStr}`;
  } catch {
    return 'Recently';
  }
}

export function formatAuditDateTime(val: any): string {
  try {
    const ms = getTimestampMs(val);
    const d = new Date(ms);
    const day = String(d.getDate()).padStart(2, '0');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const month = months[d.getMonth()];
    const year = d.getFullYear();
    const time = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    return `${day}-${month}-${year} ${time}`;
  } catch {
    return '28-Jul-2026 10:15 AM';
  }
}

export function formatDateTime(val: any): string {
  try {
    const ms = getTimestampMs(val);
    const d = new Date(ms);
    return `${d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })} ${d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })}`;
  } catch {
    return 'Recently';
  }
}
