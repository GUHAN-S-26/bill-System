import React from 'react';
import { FileText, CreditCard, UserPlus, X, Users } from 'lucide-react';

interface QuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCreateBill: () => void;
  onOpenReceivePayment: () => void;
  onOpenAddCustomer: () => void;
  onOpenManageGroups?: () => void;
}

export const QuickActionModal: React.FC<QuickActionModalProps> = ({
  isOpen,
  onClose,
  onOpenCreateBill,
  onOpenReceivePayment,
  onOpenAddCustomer,
  onOpenManageGroups,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden border border-slate-100">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50">
          <h3 className="font-bold text-slate-800 text-base">Quick Business Action</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-3">
          {/* Create Bill Button */}
          <button
            onClick={() => {
              onClose();
              onOpenCreateBill();
            }}
            className="w-full flex items-center space-x-4 p-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-xl border border-emerald-200/80 transition-colors group text-left"
          >
            <div className="w-11 h-11 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-base text-emerald-950">Create Bill</div>
              <div className="text-xs text-emerald-700 font-medium">Fast amount-only billing in &lt;20 seconds</div>
            </div>
          </button>

          {/* Receive Payment Button */}
          <button
            onClick={() => {
              onClose();
              onOpenReceivePayment();
            }}
            className="w-full flex items-center space-x-4 p-3.5 bg-blue-50 hover:bg-blue-100 text-blue-900 rounded-xl border border-blue-200/80 transition-colors group text-left"
          >
            <div className="w-11 h-11 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-base text-blue-950">Receive Payment</div>
              <div className="text-xs text-blue-700 font-medium">Record customer credit payment or settlement</div>
            </div>
          </button>

          {/* Add Customer Button */}
          <button
            onClick={() => {
              onClose();
              onOpenAddCustomer();
            }}
            className="w-full flex items-center space-x-4 p-3.5 bg-purple-50 hover:bg-purple-100 text-purple-900 rounded-xl border border-purple-200/80 transition-colors group text-left"
          >
            <div className="w-11 h-11 rounded-lg bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
              <UserPlus className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-base text-purple-950">Add Customer</div>
              <div className="text-xs text-purple-700 font-medium">Register new credit account with group & balance</div>
            </div>
          </button>

          {onOpenManageGroups && (
            <button
              onClick={() => {
                onClose();
                onOpenManageGroups();
              }}
              className="w-full flex items-center space-x-4 p-3 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-xl border border-slate-200 transition-colors text-left"
            >
              <div className="w-9 h-9 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">Customer Groups</div>
                <div className="text-[11px] text-slate-500">Manage categories & default groups</div>
              </div>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
