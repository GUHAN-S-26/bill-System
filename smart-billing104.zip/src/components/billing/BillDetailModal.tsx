import React from 'react';
import { X, Printer, Trash2, Edit3, Receipt, CheckCircle, Clock } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Bill } from '../../types';
import { formatDate, formatTime } from '../../utils/dateUtils';

interface BillDetailModalProps {
  bill: Bill | null;
  onClose: () => void;
  onEditBill?: (bill: Bill) => void;
}

export const BillDetailModal: React.FC<BillDetailModalProps> = ({ bill, onClose, onEditBill }) => {
  const { settings, deleteBill } = useApp();

  if (!bill) return null;

  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to soft-delete Bill #${bill.billNumber}?`)) {
      deleteBill(bill.billId);
      onClose();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const status = bill.pendingAmount === 0 ? 'Paid' : bill.paidAmount > 0 ? 'Partial' : 'Pending';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center space-x-2">
            <Receipt className="w-5 h-5 text-emerald-700" />
            <h3 className="font-extrabold text-slate-800 text-base">Bill #{bill.billNumber}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Body */}
        <div className="p-5 space-y-4 overflow-y-auto text-xs flex-1" id="printable-receipt">
          {/* Shop Header */}
          <div className="text-center pb-3 border-b border-slate-200">
            <h2 className="font-extrabold text-lg text-slate-900">{settings.shopName}</h2>
            <p className="text-slate-500">{settings.address}</p>
            <p className="text-slate-500 font-semibold">Ph: {settings.phone}</p>
          </div>

          {/* Customer & Bill Meta */}
          <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex justify-between">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-bold">Billed To</div>
              <div className="font-extrabold text-sm text-slate-900">{bill.customerName}</div>
              <div className="text-slate-500">{bill.groupName}</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Date & Time</div>
              <div className="font-semibold text-slate-800">
                {formatDate(bill.createdAt)}
              </div>
              <div className="text-slate-500">
                {formatTime(bill.createdAt)}
              </div>
            </div>
          </div>

          {/* Entries Table */}
          <div>
            <div className="font-bold text-slate-800 mb-1.5 uppercase text-[10px] tracking-wider">
              Itemized Amounts
            </div>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                    <th className="py-2 px-3">#</th>
                    <th className="py-2 px-3">Note / Item</th>
                    <th className="py-2 px-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {bill.entries.map((item, idx) => (
                    <tr key={item.id || idx}>
                      <td className="py-2 px-3 text-slate-400 font-bold">{idx + 1}</td>
                      <td className="py-2 px-3 text-slate-800 font-medium">
                        {item.note || `Item ${idx + 1}`}
                      </td>
                      <td className="py-2 px-3 text-right font-extrabold text-slate-900">
                        {settings.currencySymbol}
                        {item.amount.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Totals Summary */}
          <div className="space-y-1.5 pt-2 border-t border-slate-200 text-slate-700">
            <div className="flex justify-between font-bold">
              <span>Subtotal Amount:</span>
              <span className="text-slate-900 text-sm font-black">
                {settings.currencySymbol}
                {bill.subtotal.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="flex justify-between font-semibold text-emerald-700">
              <span>Amount Paid:</span>
              <span>
                {settings.currencySymbol}
                {bill.paidAmount.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="flex justify-between font-black text-rose-600 text-sm pt-1 border-t border-dashed border-slate-200">
              <span>Pending Balance:</span>
              <span>
                {settings.currencySymbol}
                {bill.pendingAmount.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Payment Method & Status */}
          <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl text-xs">
            <span className="font-bold text-slate-600">Payment Status:</span>
            <span
              className={`font-black px-2.5 py-0.5 rounded-full border text-[11px] ${
                status === 'Paid'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : status === 'Partial'
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-rose-50 text-rose-700 border-rose-200'
              }`}
            >
              {status.toUpperCase()} ({bill.paymentMethod.toUpperCase()})
            </span>
          </div>

          {bill.remarks && (
            <div className="text-slate-500 italic text-[11px]">Note: {bill.remarks}</div>
          )}
        </div>

        {/* Action Controls */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-2">
          <button
            onClick={handleDelete}
            className="p-2.5 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors"
            title="Delete Bill"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2.5 bg-slate-800 text-white hover:bg-slate-900 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Printer className="w-4 h-4" />
              <span>Print</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2.5 bg-emerald-700 text-white hover:bg-emerald-800 font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
