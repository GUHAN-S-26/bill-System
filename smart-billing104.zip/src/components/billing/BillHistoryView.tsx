import React, { useState } from 'react';
import { Search, Receipt, Plus, ChevronRight, CreditCard, ArrowDownLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Bill, Payment } from '../../types';
import { formatDate, getTimestampMs } from '../../utils/dateUtils';

interface BillHistoryViewProps {
  onOpenCreateBill: () => void;
  onOpenBillDetail: (bill: Bill) => void;
  onOpenPaymentDetail?: (payment: Payment) => void;
}

export const BillHistoryView: React.FC<BillHistoryViewProps> = ({
  onOpenCreateBill,
  onOpenBillDetail,
  onOpenPaymentDetail,
}) => {
  const { bills, payments, settings } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all_bills' | 'payments' | 'pending' | 'paid'>('all_bills');

  const activeBills = bills.filter((b) => !b.isDeleted);
  const activePayments = payments.filter((p) => !p.isDeleted);

  const filteredBills = activeBills.filter((b) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesQuery =
      b.billNumber.toLowerCase().includes(q) ||
      b.customerName.toLowerCase().includes(q) ||
      b.groupName.toLowerCase().includes(q);

    let matchesStatus = true;
    if (activeTab === 'pending') matchesStatus = b.pendingAmount > 0;
    if (activeTab === 'paid') matchesStatus = b.pendingAmount === 0;

    return matchesQuery && matchesStatus;
  });

  const filteredPayments = activePayments.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      p.customerName.toLowerCase().includes(q) ||
      p.paymentMethod.toLowerCase().includes(q) ||
      p.paymentId.toLowerCase().includes(q)
    );
  });

  const totalBilled = activeBills.reduce((sum, b) => sum + b.subtotal, 0);
  const totalCollected = activePayments.reduce((sum, p) => sum + p.amount, 0) + activeBills.reduce((sum, b) => sum + b.paidAmount, 0);

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">Billing & Payment Transactions</h1>
          <p className="text-xs text-slate-500 font-medium">
            Total Billed: <span className="font-bold text-slate-800">{settings.currencySymbol}{totalBilled.toLocaleString('en-IN')}</span> • Collected: <span className="font-bold text-emerald-700">{settings.currencySymbol}{totalCollected.toLocaleString('en-IN')}</span>
          </p>
        </div>
        <button
          onClick={onOpenCreateBill}
          className="flex items-center space-x-1.5 bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-2xs hover:bg-emerald-800 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Bill</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by Invoice #, Customer, or Payment mode..."
          className="w-full bg-white border border-slate-200 pl-10 pr-4 py-2.5 rounded-xl text-sm focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 text-slate-900 placeholder-slate-400 shadow-2xs"
        />
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 text-xs overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('all_bills')}
          className={`px-3.5 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap ${
            activeTab === 'all_bills'
              ? 'bg-slate-900 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          All Bills ({activeBills.length})
        </button>
        <button
          onClick={() => setActiveTab('payments')}
          className={`px-3.5 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap ${
            activeTab === 'payments'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Payments Received ({activePayments.length})
        </button>
        <button
          onClick={() => setActiveTab('pending')}
          className={`px-3.5 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap ${
            activeTab === 'pending'
              ? 'bg-rose-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Pending Credit Bills
        </button>
        <button
          onClick={() => setActiveTab('paid')}
          className={`px-3.5 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap ${
            activeTab === 'paid'
              ? 'bg-emerald-700 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Fully Paid
        </button>
      </div>

      {/* Content List */}
      <div className="space-y-2.5">
        {activeTab === 'payments' ? (
          filteredPayments.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 text-sm">
              No payments found matching filters.
            </div>
          ) : (
            filteredPayments.map((p) => (
              <div
                key={p.paymentId}
                onClick={() => onOpenPaymentDetail && onOpenPaymentDetail(p)}
                className="bg-white rounded-2xl border border-slate-200/80 p-3.5 shadow-2xs hover:border-blue-300 transition-colors cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 font-extrabold text-xs flex items-center justify-center shrink-0 border border-blue-100">
                    <ArrowDownLeft className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-extrabold text-slate-900 text-sm">{p.customerName}</div>
                    <div className="text-xs text-slate-400 font-medium flex items-center gap-2">
                      <span className="text-blue-600 font-bold uppercase">{p.paymentMethod}</span>
                      <span>•</span>
                      <span>{formatDate(p.createdAt)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3 text-right">
                  <div>
                    <div className="font-black text-emerald-700 text-base">
                      + {settings.currencySymbol}
                      {p.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </div>
                    {p.remarks && <div className="text-[10px] text-slate-400">{p.remarks}</div>}
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border bg-blue-50 text-blue-700 border-blue-200">
                    Received
                  </span>

                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </div>
            ))
          )
        ) : filteredBills.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 text-sm">
            No bills found matching filters.
          </div>
        ) : (
          filteredBills.map((b) => {
            const status = b.pendingAmount === 0 ? 'Paid' : b.paidAmount > 0 ? 'Partial' : 'Pending';

            return (
              <div
                key={b.billId}
                onClick={() => onOpenBillDetail(b)}
                className="bg-white rounded-2xl border border-slate-200/80 p-3.5 shadow-2xs hover:border-emerald-300 transition-colors cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 font-extrabold text-xs flex items-center justify-center shrink-0 border border-emerald-100">
                    <Receipt className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-extrabold text-slate-900 text-sm">{b.customerName}</div>
                    <div className="text-xs text-slate-400 font-medium flex items-center gap-2">
                      <span>#{b.billNumber}</span>
                      <span>•</span>
                      <span>{formatDate(b.createdAt)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3 text-right">
                  <div>
                    <div className="font-black text-slate-900 text-base">
                      {settings.currencySymbol}
                      {b.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </div>
                    {b.pendingAmount > 0 && (
                      <div className="text-[11px] font-bold text-rose-600">
                        Pending: {settings.currencySymbol}{b.pendingAmount}
                      </div>
                    )}
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      status === 'Paid'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : status === 'Partial'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-rose-50 text-rose-700 border-rose-200'
                    }`}
                  >
                    {status}
                  </span>

                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
