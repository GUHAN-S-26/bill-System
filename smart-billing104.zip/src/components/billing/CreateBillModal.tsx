import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Receipt, CheckCircle2, User, Sparkles, CreditCard } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Customer, BillEntry, PaymentMethod, Bill } from '../../types';

interface CreateBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedCustomer?: Customer | null;
  onBillCreated?: (bill: Bill) => void;
}

export const CreateBillModal: React.FC<CreateBillModalProps> = ({
  isOpen,
  onClose,
  preSelectedCustomer,
  onBillCreated,
}) => {
  const { customers, addBill, settings } = useApp();

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerQuery, setCustomerQuery] = useState('');
  const [entries, setEntries] = useState<BillEntry[]>([
    { id: '1', amount: 0, note: '' },
  ]);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('credit');
  const [remarks, setRemarks] = useState('');
  const [error, setError] = useState('');

  const activeCustomers = customers.filter((c) => !c.isDeleted && c.isActive);

  useEffect(() => {
    if (preSelectedCustomer) {
      setSelectedCustomerId(preSelectedCustomer.customerId);
      setCustomerQuery(preSelectedCustomer.customerName);
    } else if (activeCustomers.length > 0) {
      setSelectedCustomerId(activeCustomers[0].customerId);
      setCustomerQuery(activeCustomers[0].customerName);
    }
    setEntries([{ id: '1', amount: 0, note: '' }]);
    setPaidAmount(0);
    setPaymentMethod('credit');
    setRemarks('');
    setError('');
  }, [preSelectedCustomer, isOpen]);

  if (!isOpen) return null;

  const currentCustomer = activeCustomers.find((c) => c.customerId === selectedCustomerId);

  const subtotal = entries.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const pendingAmount = Math.max(0, subtotal - (Number(paidAmount) || 0));

  const handleAddEntry = () => {
    setEntries((prev) => [
      ...prev,
      { id: Math.random().toString(36).substring(2, 7), amount: 0, note: '' },
    ]);
  };

  const handleRemoveEntry = (id: string) => {
    if (entries.length === 1) return;
    setEntries((prev) => prev.filter((e) => e.id !== id));
  };

  const handleEntryChange = (id: string, field: 'amount' | 'note', value: any) => {
    setEntries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, [field]: value } : e))
    );
  };

  const setPaidPreset = (preset: 'full' | 'half' | 'zero') => {
    if (preset === 'full') {
      setPaidAmount(subtotal);
      if (paymentMethod === 'credit') setPaymentMethod('cash');
    } else if (preset === 'half') {
      setPaidAmount(Math.round(subtotal / 2));
      if (paymentMethod === 'credit') setPaymentMethod('cash');
    } else {
      setPaidAmount(0);
      setPaymentMethod('credit');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCustomer) {
      setError('Please select a valid customer.');
      return;
    }

    const validEntries = entries.filter((e) => Number(e.amount) > 0);
    if (validEntries.length === 0) {
      setError('Please enter at least one item amount > 0.');
      return;
    }

    const finalBill = addBill({
      customerId: currentCustomer.customerId,
      customerName: currentCustomer.customerName,
      groupId: currentCustomer.groupId,
      groupName: currentCustomer.groupName,
      entries: validEntries,
      subtotal,
      paidAmount: Number(paidAmount) || 0,
      pendingAmount,
      paymentMethod,
      remarks: remarks.trim(),
    });

    if (onBillCreated) onBillCreated(finalBill);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-100 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center space-x-2">
            <Receipt className="w-5 h-5 text-emerald-700" />
            <h3 className="font-extrabold text-slate-800 text-base">
              Fast Amount Billing (&lt;20s)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold">
              {error}
            </div>
          )}

          {/* Customer Selection Autocomplete */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">
              Select Customer <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => {
                setSelectedCustomerId(e.target.value);
                const cust = activeCustomers.find((c) => c.customerId === e.target.value);
                if (cust) setCustomerQuery(cust.customerName);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            >
              {activeCustomers.map((c) => (
                <option key={c.customerId} value={c.customerId}>
                  {c.customerName} ({c.groupName}) - Current Bal: {settings.currencySymbol}
                  {c.currentBalance.toLocaleString('en-IN')}
                </option>
              ))}
            </select>
          </div>

          {/* Item Amount Entries List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-slate-800 font-extrabold">Bill Items / Amounts</label>
              <button
                type="button"
                onClick={handleAddEntry}
                className="text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 text-[11px]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Item</span>
              </button>
            </div>

            <div className="space-y-2 bg-slate-50 p-3 rounded-2xl border border-slate-200">
              {entries.map((entry, index) => (
                <div key={entry.id} className="flex items-center space-x-2">
                  <span className="text-slate-400 font-bold w-4 text-right">{index + 1}.</span>
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-2.5 font-bold text-slate-400">
                      {settings.currencySymbol}
                    </span>
                    <input
                      type="number"
                      value={entry.amount || ''}
                      onChange={(e) =>
                        handleEntryChange(entry.id, 'amount', parseFloat(e.target.value) || 0)
                      }
                      placeholder="Amount"
                      className="w-full bg-white border border-slate-200 rounded-xl pl-7 pr-3 py-2 text-sm font-black text-slate-900 focus:outline-hidden focus:border-emerald-600"
                      required
                    />
                  </div>
                  <input
                    type="text"
                    value={entry.note}
                    onChange={(e) => handleEntryChange(entry.id, 'note', e.target.value)}
                    placeholder="Note (e.g. Rice, Oil)"
                    className="w-28 sm:w-36 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-hidden focus:border-emerald-600"
                  />
                  {entries.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveEntry(entry.id)}
                      className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Subtotal Calculation Box */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-3.5 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-bold text-emerald-800 uppercase">Subtotal Amount</div>
              <div className="text-2xl font-black text-emerald-950">
                {settings.currencySymbol}
                {subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] font-bold text-slate-500 uppercase">Auto Pending</div>
              <div className="text-lg font-black text-rose-600">
                {settings.currencySymbol}
                {pendingAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          {/* Paid Amount at Billing Time */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-slate-700 font-bold">Paid Now ({settings.currencySymbol})</label>
              <div className="flex items-center space-x-1.5">
                <button
                  type="button"
                  onClick={() => setPaidPreset('full')}
                  className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-bold hover:bg-emerald-200 text-[10px]"
                >
                  Full ({settings.currencySymbol}{subtotal})
                </button>
                <button
                  type="button"
                  onClick={() => setPaidPreset('half')}
                  className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-bold hover:bg-blue-200 text-[10px]"
                >
                  Half ({settings.currencySymbol}{Math.round(subtotal / 2)})
                </button>
                <button
                  type="button"
                  onClick={() => setPaidPreset('zero')}
                  className="px-2 py-0.5 bg-slate-200 text-slate-700 rounded font-bold hover:bg-slate-300 text-[10px]"
                >
                  ₹0 Credit
                </button>
              </div>
            </div>

            <input
              type="number"
              value={paidAmount}
              onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
              placeholder="0.00"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
          </div>

          {/* Payment Method Selector */}
          {paidAmount > 0 && (
            <div>
              <label className="block text-slate-700 font-bold mb-1">Payment Method</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-colors ${
                    paymentMethod === 'cash'
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  💵 Cash
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-colors ${
                    paymentMethod === 'upi'
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  📱 GPay / UPI
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank_transfer')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-colors ${
                    paymentMethod === 'bank_transfer'
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  🏦 Bank Transfer
                </button>
              </div>
            </div>
          )}

          {/* Remarks */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">Remarks / Reference</label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Delivered to home / GPay reference..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-medium text-slate-900 focus:outline-hidden focus:border-emerald-600"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 text-slate-600 bg-slate-100 hover:bg-slate-200 font-bold rounded-xl text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center space-x-2 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-black text-sm rounded-xl shadow-xs transition-colors"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>Save & Complete Bill</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
