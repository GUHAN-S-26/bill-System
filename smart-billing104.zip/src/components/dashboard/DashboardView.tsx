import React, { useState } from 'react';
import {
  ShoppingBag,
  Wallet,
  Clock,
  Users,
  MoreVertical,
  ChevronRight,
  CheckCircle2,
  RotateCw,
  TrendingUp,
  ArrowUpRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Bill, Payment } from '../../types';
import { getYYYYMMDD, getTimestampMs, formatTransactionDateTime } from '../../utils/dateUtils';

interface DashboardViewProps {
  onOpenCreateBill: () => void;
  onOpenReceivePayment: () => void;
  onSelectCustomer: (customerId: string) => void;
  onViewAllTransactions: () => void;
  onOpenBillDetail: (bill: Bill) => void;
  onOpenPaymentDetail?: (payment: Payment) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenCreateBill,
  onOpenReceivePayment,
  onSelectCustomer,
  onViewAllTransactions,
  onOpenBillDetail,
  onOpenPaymentDetail,
}) => {
  const { customers, bills, payments, settings, isOnline, triggerSync, isSyncing, syncQueue } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'bills' | 'payments'>('all');

  // Calculate today's metrics safely
  const todayStr = getYYYYMMDD(new Date());

  const activeBills = bills.filter((b) => !b.isDeleted);
  const activePayments = payments.filter((p) => !p.isDeleted);

  const todayBills = activeBills.filter((b) => getYYYYMMDD(b.createdAt) === todayStr);
  const todayPayments = activePayments.filter((p) => getYYYYMMDD(p.createdAt) === todayStr);

  const todaySalesAmount = todayBills.reduce((sum, b) => sum + b.subtotal, 0);

  const todayBillCollections = todayBills.reduce((sum, b) => sum + b.paidAmount, 0);
  const todayDirectCollections = todayPayments.reduce((sum, p) => sum + p.amount, 0);
  const todayCollectionAmount = todayBillCollections + todayDirectCollections;

  const totalPendingAmount = customers
    .filter((c) => !c.isDeleted && c.isActive)
    .reduce((sum, c) => sum + Math.max(0, c.currentBalance), 0);

  const totalCustomersCount = customers.filter((c) => !c.isDeleted && c.isActive).length;

  // Merged Recent Transactions List with robust timestamp sorting
  const recentTransactions: (
    | { kind: 'bill'; data: Bill; timestamp: number }
    | { kind: 'payment'; data: Payment; timestamp: number }
  )[] = [
    ...activeBills.map((b) => ({
      kind: 'bill' as const,
      data: b,
      timestamp: getTimestampMs(b.createdAt),
    })),
    ...activePayments.map((p) => ({
      kind: 'payment' as const,
      data: p,
      timestamp: getTimestampMs(p.createdAt),
    })),
  ]
    .filter((item) => {
      if (activeFilter === 'bills') return item.kind === 'bill';
      if (activeFilter === 'payments') return item.kind === 'payment';
      return true;
    })
    .sort((a, b) => {
      if (b.timestamp !== a.timestamp) {
        return b.timestamp - a.timestamp;
      }
      const idA = a.kind === 'bill' ? a.data.billId : a.data.paymentId;
      const idB = b.kind === 'bill' ? b.data.billId : b.data.paymentId;
      return idB.localeCompare(idA);
    })
    .slice(0, 10);

  const getInitials = (name: string) => {
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Top Sync Banner matching PRD/Screenshot */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-3.5 flex items-center justify-between shadow-2xs">
        <div className="flex items-center space-x-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-800 text-sm">
                Sync Status: {isOnline ? 'Online' : 'Offline'}
              </span>
              {syncQueue.length > 0 && (
                <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded-full">
                  {syncQueue.length} queued
                </span>
              )}
            </div>
            <div className="text-xs text-slate-500">
              Last synced: {settings.lastSyncedAt ? 'Just now' : 'Never'}
            </div>
          </div>
        </div>
        <button
          onClick={triggerSync}
          disabled={isSyncing}
          className="p-2 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl transition-colors"
          title="Force Sync"
        >
          <RotateCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-emerald-600' : ''}`} />
        </button>
      </div>

      {/* 2x2 Metric Cards Grid */}
      <div className="grid grid-cols-2 gap-3.5">
        {/* Today's Sales Card */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-2xs relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-emerald-700 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-slate-600">Today's Sales</span>
            <button className="text-slate-300 hover:text-slate-500">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {settings.currencySymbol}
              {todaySalesAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className="flex items-center text-xs text-emerald-600 font-semibold mt-1 gap-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>12.5%</span>
              <span className="text-slate-400 font-normal">vs yesterday</span>
            </div>
          </div>

          {/* Sparkline Graphic */}
          <div className="mt-2 h-7 w-full overflow-hidden opacity-80">
            <svg viewBox="0 0 100 25" className="w-full h-full stroke-emerald-500 fill-none stroke-2">
              <path d="M0 20 Q 15 18, 25 10 T 50 15 T 75 5 T 100 12" />
            </svg>
          </div>
        </div>

        {/* Today's Collection Card */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-2xs relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-emerald-700 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-slate-600">Today's Collection</span>
            <button className="text-slate-300 hover:text-slate-500">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {settings.currencySymbol}
              {todayCollectionAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className="flex items-center text-xs text-emerald-600 font-semibold mt-1 gap-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>8.3%</span>
              <span className="text-slate-400 font-normal">vs yesterday</span>
            </div>
          </div>

          {/* Sparkline Graphic */}
          <div className="mt-2 h-7 w-full overflow-hidden opacity-80">
            <svg viewBox="0 0 100 25" className="w-full h-full stroke-emerald-500 fill-none stroke-2">
              <path d="M0 22 Q 20 18, 35 12 T 65 18 T 100 6" />
            </svg>
          </div>
        </div>

        {/* Total Pending Card */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-2xs relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-full bg-amber-100/70 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-slate-600">Total Pending</span>
            <button className="text-slate-300 hover:text-slate-500">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {settings.currencySymbol}
              {totalPendingAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className="flex items-center text-xs text-amber-600 font-semibold mt-1 gap-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>15.7%</span>
              <span className="text-slate-400 font-normal">vs yesterday</span>
            </div>
          </div>

          {/* Sparkline Graphic */}
          <div className="mt-2 h-7 w-full overflow-hidden opacity-80">
            <svg viewBox="0 0 100 25" className="w-full h-full stroke-amber-500 fill-none stroke-2">
              <path d="M0 18 Q 20 22, 40 14 T 70 19 T 100 8" />
            </svg>
          </div>
        </div>

        {/* Total Customers Card */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-2xs relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-emerald-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-slate-600">Total Customers</span>
            <button className="text-slate-300 hover:text-slate-500">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {totalCustomersCount.toLocaleString('en-IN')}
            </div>
            <div className="flex items-center text-xs text-emerald-600 font-semibold mt-1 gap-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>6.4%</span>
              <span className="text-slate-400 font-normal">vs last month</span>
            </div>
          </div>

          {/* Sparkline Graphic */}
          <div className="mt-2 h-7 w-full overflow-hidden opacity-80">
            <svg viewBox="0 0 100 25" className="w-full h-full stroke-emerald-500 fill-none stroke-2">
              <path d="M0 20 Q 25 15, 45 22 T 75 10 T 100 16" />
            </svg>
          </div>
        </div>
      </div>

      {/* Quick Action Shortcuts Banner */}
      <div className="grid grid-cols-2 gap-3 pt-1">
        <button
          onClick={onOpenCreateBill}
          className="flex items-center justify-center space-x-2 bg-emerald-700 text-white font-bold text-sm py-3 px-4 rounded-xl shadow-xs hover:bg-emerald-800 transition-colors"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>New Bill</span>
        </button>
        <button
          onClick={onOpenReceivePayment}
          className="flex items-center justify-center space-x-2 bg-slate-900 text-white font-bold text-sm py-3 px-4 rounded-xl shadow-xs hover:bg-slate-800 transition-colors"
        >
          <Wallet className="w-4 h-4 text-emerald-400" />
          <span>Receive Payment</span>
        </button>
      </div>

      {/* Recent Transactions List Section */}
      <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-extrabold text-slate-900 text-base">Recent Transactions</h2>
          <button
            onClick={onViewAllTransactions}
            className="text-emerald-700 hover:text-emerald-800 text-xs font-extrabold"
          >
            View All
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center space-x-2 mb-3 text-xs">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1 rounded-full font-bold transition-colors ${
              activeFilter === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setActiveFilter('bills')}
            className={`px-3 py-1 rounded-full font-bold transition-colors ${
              activeFilter === 'bills'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Bills
          </button>
          <button
            onClick={() => setActiveFilter('payments')}
            className={`px-3 py-1 rounded-full font-bold transition-colors ${
              activeFilter === 'payments'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Payments
          </button>
        </div>

        {/* Transactions Rows */}
        <div className="divide-y divide-slate-100">
          {recentTransactions.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-sm">No transactions yet today.</div>
          ) : (
            recentTransactions.map((tx) => {
              if (tx.kind === 'bill') {
                const b = tx.data;
                const status =
                  b.pendingAmount === 0 ? 'Paid' : b.paidAmount > 0 ? 'Partial' : 'Pending';

                const statusStyles =
                  status === 'Paid'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : status === 'Partial'
                    ? 'bg-amber-50 text-amber-700 border-amber-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200';

                return (
                  <div
                    key={b.billId}
                    onClick={() => onOpenBillDetail(b)}
                    className="py-3 flex items-center justify-between hover:bg-slate-50 px-2 rounded-xl cursor-pointer transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center shrink-0 border border-slate-200">
                        {getInitials(b.customerName)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 text-sm">{b.customerName}</div>
                        <div className="text-xs text-slate-400 font-medium">Bill #{b.billNumber}</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 text-right">
                      <div>
                        <div className="font-extrabold text-slate-900 text-sm">
                          {settings.currencySymbol}
                          {b.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </div>
                        <div className="text-[11px] text-slate-400">{formatTransactionDateTime(b.createdAt)}</div>
                      </div>

                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${statusStyles}`}
                      >
                        {status}
                      </span>

                      <ChevronRight className="w-4 h-4 text-slate-300" />
                    </div>
                  </div>
                );
              } else {
                const p = tx.data;
                return (
                  <div
                    key={p.paymentId}
                    onClick={() =>
                      onOpenPaymentDetail ? onOpenPaymentDetail(p) : onSelectCustomer(p.customerId)
                    }
                    className="py-3 flex items-center justify-between hover:bg-slate-50 px-2 rounded-xl cursor-pointer transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0 border border-blue-100">
                        {getInitials(p.customerName)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 text-sm">{p.customerName}</div>
                        <div className="text-xs text-blue-600 font-medium">
                          Payment ({p.paymentMethod.toUpperCase()})
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 text-right">
                      <div>
                        <div className="font-extrabold text-emerald-700 text-sm">
                          + {settings.currencySymbol}
                          {p.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </div>
                        <div className="text-[11px] text-slate-400">{formatTransactionDateTime(p.createdAt)}</div>
                      </div>

                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full border bg-blue-50 text-blue-700 border-blue-200">
                        Received
                      </span>

                      <ChevronRight className="w-4 h-4 text-slate-300" />
                    </div>
                  </div>
                );
              }
            })
          )}
        </div>
      </div>
    </div>
  );
};
