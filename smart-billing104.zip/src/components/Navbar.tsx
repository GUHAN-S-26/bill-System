import React from 'react';
import { RefreshCw, Settings, Store, Wifi, WifiOff, ChevronDown } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface NavbarProps {
  onOpenSettings: () => void;
  onOpenBackupSync: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSettings, onOpenBackupSync }) => {
  const { settings, user, isOnline, toggleOnlineStatus, isSyncing, triggerSync, syncQueue } = useApp();

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 px-4 py-3 shadow-xs">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        {/* Shop & Owner Info */}
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center p-1 shadow-xs">
            {/* Shop Logo Placeholder */}
            <div className="w-full h-full rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-lg">
              {settings.shopName.charAt(0)}
            </div>
          </div>
          <div>
            <h1 className="font-extrabold text-slate-900 text-lg leading-tight flex items-center gap-1.5">
              {settings.shopName}
            </h1>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
              <span>{user?.name || settings.ownerName || 'Owner'}</span>
              <span className="inline-block w-1 h-1 rounded-full bg-slate-300"></span>
              <span className="text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded text-[11px]">
                {user?.role ? user.role.toUpperCase() : 'OWNER'}
              </span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2">
          {/* Online / Offline Toggle Badge */}
          <button
            onClick={toggleOnlineStatus}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
              isOnline
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
            }`}
            title="Click to toggle Online/Offline simulation"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
              }`}
            ></span>
            <span className="hidden sm:inline">{isOnline ? 'Online' : 'Offline'}</span>
          </button>

          {/* Sync Trigger Button */}
          <button
            onClick={onOpenBackupSync}
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded-lg relative transition-colors"
            title="Sync Status & Backup"
          >
            <RefreshCw className={`w-5 h-5 ${isSyncing ? 'animate-spin text-emerald-600' : ''}`} />
            {syncQueue.length > 0 && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-amber-500 border-2 border-white rounded-full"></span>
            )}
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors"
            title="Shop Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
