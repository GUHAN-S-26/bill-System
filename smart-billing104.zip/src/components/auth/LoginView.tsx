import React, { useState } from 'react';
import { Store, Lock, User, ArrowRight, ShieldCheck, Loader2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const LoginView: React.FC = () => {
  const { login, settings } = useApp();

  const [username, setUsername] = useState('venkatesh');
  const [password, setPassword] = useState('2003');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError('Please enter username and password.');
      return;
    }

    setIsLoading(true);
    setError('');

    const res = await login(username.trim(), password.trim());
    setIsLoading(false);

    if (!res.success) {
      setError(res.message || 'Firebase Authentication failed. Check credentials.');
    }
  };

  const handleFillDemo = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
    setError('');
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6">
        {/* Logo Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg shadow-emerald-600/30">
            <Store className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black text-slate-900">{settings.shopName || 'Shankar Shop'}</h1>
          <p className="text-xs text-slate-500 font-medium">
            Firebase Auth - Shop Owner Portal
          </p>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-bold text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-700 font-bold mb-1">Owner Username or Email</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="venkatesh / priya / deepika"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-bold mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                required
              />
            </div>
          </div>

          {/* Preset Owner Credentials Selection */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-2">
            <span className="text-slate-500 font-bold text-[11px] block">Test Owner Accounts (Password: 2003):</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { name: 'venkatesh', label: 'Venkatesh' },
                { name: 'priya', label: 'Priya' },
                { name: 'deepika', label: 'Deepika' },
              ].map((owner) => (
                <button
                  key={owner.name}
                  type="button"
                  onClick={() => handleFillDemo(owner.name, '2003')}
                  className={`py-1.5 px-2 rounded-xl border text-[11px] font-bold transition-all ${
                    username.toLowerCase() === owner.name
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-300'
                  }`}
                >
                  {owner.label}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center space-x-2 py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-emerald-700/20 transition-all active:scale-[0.98] disabled:opacity-60"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Authenticating with Firebase...</span>
              </>
            ) : (
              <>
                <span>Log In via Firebase</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="pt-2 text-center text-[11px] text-slate-400 flex items-center justify-center gap-1 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Connected to Firebase Authentication</span>
        </div>
      </div>
    </div>
  );
};
