import React, { useState } from 'react';
import { FileDown, Calendar, TrendingUp, Clock, Users, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { generateBusinessReportPDF } from '../../services/pdfGenerator';
import { exportToCSV } from '../../services/sheetsBackup';
import { getYYYYMMDD, getYYYYMM, formatTime, formatDate } from '../../utils/dateUtils';

export const ReportsView: React.FC = () => {
  const { customers, bills, payments, settings } = useApp();

  const [reportTab, setReportTab] = useState<'daily' | 'monthly' | 'pending' | 'customer'>('daily');

  const activeBills = bills.filter((b) => !b.isDeleted);
  const activePayments = payments.filter((p) => !p.isDeleted);
  const activeCustomers = customers.filter((c) => !c.isDeleted && c.isActive);

  // Daily Calculations
  const todayStr = getYYYYMMDD(new Date());
  const todayBills = activeBills.filter((b) => getYYYYMMDD(b.createdAt) === todayStr);
  const todayPayments = activePayments.filter((p) => getYYYYMMDD(p.createdAt) === todayStr);

  const todaySales = todayBills.reduce((sum, b) => sum + b.subtotal, 0);
  const todayCollection =
    todayBills.reduce((sum, b) => sum + b.paidAmount, 0) +
    todayPayments.reduce((sum, p) => sum + p.amount, 0);

  // Monthly Calculations
  const currentMonthStr = getYYYYMM(new Date());
  const monthBills = activeBills.filter((b) => getYYYYMM(b.createdAt) === currentMonthStr);
  const monthPayments = activePayments.filter((p) => getYYYYMM(p.createdAt) === currentMonthStr);

  const monthSales = monthBills.reduce((sum, b) => sum + b.subtotal, 0);
  const monthCollection =
    monthBills.reduce((sum, b) => sum + b.paidAmount, 0) +
    monthPayments.reduce((sum, p) => sum + p.amount, 0);

  // Pending Credit Customers
  const pendingCustomers = activeCustomers
    .filter((c) => c.currentBalance > 0)
    .sort((a, b) => b.currentBalance - a.currentBalance);

  const totalPendingSum = pendingCustomers.reduce((sum, c) => sum + c.currentBalance, 0);

  // Handle PDF Export
  const handleExportPDF = () => {
    if (reportTab === 'daily') {
      const summary = [
        { label: "Today's Sales", value: `${settings.currencySymbol}${todaySales.toLocaleString('en-IN')}` },
        { label: "Today's Collection", value: `${settings.currencySymbol}${todayCollection.toLocaleString('en-IN')}` },
        { label: 'Bills Issued', value: String(todayBills.length) },
      ];
      const headers = ['TIME', 'CUSTOMER', 'TYPE / REF', 'BILL AMOUNT', 'PAID AMOUNT'];
      const rows = [
        ...todayBills.map((b) => [
          formatTime(b.createdAt),
          b.customerName,
          `Bill #${b.billNumber}`,
          `${settings.currencySymbol}${b.subtotal}`,
          `${settings.currencySymbol}${b.paidAmount}`,
        ]),
        ...todayPayments.map((p) => [
          formatTime(p.createdAt),
          p.customerName,
          `Payment (${p.paymentMethod.toUpperCase()})`,
          '-',
          `${settings.currencySymbol}${p.amount}`,
        ]),
      ];
      generateBusinessReportPDF(settings, 'Daily Sales & Collection Report', summary, headers, rows);
    } else if (reportTab === 'monthly') {
      const summary = [
        { label: 'Monthly Sales', value: `${settings.currencySymbol}${monthSales.toLocaleString('en-IN')}` },
        { label: 'Monthly Collection', value: `${settings.currencySymbol}${monthCollection.toLocaleString('en-IN')}` },
        { label: 'Total Month Bills', value: String(monthBills.length) },
      ];
      const headers = ['DATE', 'CUSTOMER', 'INV #', 'AMOUNT', 'METHOD'];
      const rows = monthBills.map((b) => [
        formatDate(b.createdAt),
        b.customerName,
        b.billNumber,
        `${settings.currencySymbol}${b.subtotal}`,
        b.paymentMethod.toUpperCase(),
      ]);
      generateBusinessReportPDF(settings, 'Monthly Business Report', summary, headers, rows);
    } else if (reportTab === 'pending') {
      const summary = [
        { label: 'Total Pending Credit', value: `${settings.currencySymbol}${totalPendingSum.toLocaleString('en-IN')}` },
        { label: 'Credit Customers', value: String(pendingCustomers.length) },
      ];
      const headers = ['CUSTOMER NAME', 'PHONE', 'GROUP', 'PURCHASES', 'PENDING BALANCE'];
      const rows = pendingCustomers.map((c) => [
        c.customerName,
        c.phone || 'N/A',
        c.groupName,
        `${settings.currencySymbol}${c.totalPurchase}`,
        `${settings.currencySymbol}${c.currentBalance}`,
      ]);
      generateBusinessReportPDF(settings, 'Pending Credit Summary Report', summary, headers, rows);
    } else {
      const summary = [
        { label: 'Total Customers', value: String(activeCustomers.length) },
        { label: 'Total Credit Due', value: `${settings.currencySymbol}${totalPendingSum.toLocaleString('en-IN')}` },
      ];
      const headers = ['CUSTOMER NAME', 'GROUP', 'TOTAL BILLS', 'TOTAL PAID', 'CURRENT BALANCE'];
      const rows = activeCustomers.map((c) => [
        c.customerName,
        c.groupName,
        `${settings.currencySymbol}${c.totalPurchase}`,
        `${settings.currencySymbol}${c.totalPaid}`,
        `${settings.currencySymbol}${c.currentBalance}`,
      ]);
      generateBusinessReportPDF(settings, 'Customer Directory Summary Report', summary, headers, rows);
    }
  };

  const handleExportCSV = () => {
    if (reportTab === 'pending') {
      const headers = ['Customer Name', 'Phone', 'Group', 'Opening Balance', 'Total Purchase', 'Total Paid', 'Current Balance'];
      const rows = pendingCustomers.map((c) => [
        c.customerName,
        c.phone,
        c.groupName,
        c.openingBalance,
        c.totalPurchase,
        c.totalPaid,
        c.currentBalance,
      ]);
      exportToCSV('Pending_Credit_Report', headers, rows);
    } else {
      const headers = ['Customer Name', 'Group', 'Total Purchase', 'Total Paid', 'Current Balance'];
      const rows = activeCustomers.map((c) => [
        c.customerName,
        c.groupName,
        c.totalPurchase,
        c.totalPaid,
        c.currentBalance,
      ]);
      exportToCSV('Customer_Summary_Report', headers, rows);
    }
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">Business Reports</h1>
          <p className="text-xs text-slate-500 font-medium">
            Financial analytics & exportable PDF statements
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportCSV}
            className="p-2 text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 font-bold text-xs shadow-2xs"
            title="Export CSV"
          >
            CSV
          </button>
          <button
            onClick={handleExportPDF}
            className="flex items-center space-x-1.5 bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-2xs hover:bg-emerald-800 transition-colors"
          >
            <FileDown className="w-4 h-4" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="grid grid-cols-4 gap-2 bg-slate-100 p-1 rounded-xl text-xs font-bold">
        <button
          onClick={() => setReportTab('daily')}
          className={`py-2 rounded-lg text-center transition-colors ${
            reportTab === 'daily' ? 'bg-white text-emerald-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Daily
        </button>
        <button
          onClick={() => setReportTab('monthly')}
          className={`py-2 rounded-lg text-center transition-colors ${
            reportTab === 'monthly' ? 'bg-white text-emerald-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Monthly
        </button>
        <button
          onClick={() => setReportTab('pending')}
          className={`py-2 rounded-lg text-center transition-colors ${
            reportTab === 'pending' ? 'bg-white text-rose-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Pending Credit
        </button>
        <button
          onClick={() => setReportTab('customer')}
          className={`py-2 rounded-lg text-center transition-colors ${
            reportTab === 'customer' ? 'bg-white text-emerald-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Customer Wise
        </button>
      </div>

      {/* Report Tab Content */}
      {reportTab === 'daily' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
              <div className="text-xs text-slate-400 font-bold uppercase">Today's Sales</div>
              <div className="text-xl font-black text-slate-900 mt-1">
                {settings.currencySymbol}
                {todaySales.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">{todayBills.length} bills generated</div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
              <div className="text-xs text-slate-400 font-bold uppercase">Today's Collection</div>
              <div className="text-xl font-black text-emerald-700 mt-1">
                {settings.currencySymbol}
                {todayCollection.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Cash & digital payments
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
            <h3 className="font-extrabold text-slate-900 text-sm mb-3">Today's Activity Log</h3>
            <div className="divide-y divide-slate-100 text-xs">
              {todayBills.map((b) => (
                <div key={b.billId} className="py-2.5 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-800">{b.customerName}</span>
                    <span className="text-slate-400 text-[11px] block">Bill #{b.billNumber}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-extrabold text-slate-900">{settings.currencySymbol}{b.subtotal}</span>
                    <span className="text-[10px] text-emerald-700 block font-semibold">Paid: {settings.currencySymbol}{b.paidAmount}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {reportTab === 'monthly' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
              <div className="text-xs text-slate-400 font-bold uppercase">Monthly Sales</div>
              <div className="text-xl font-black text-slate-900 mt-1">
                {settings.currencySymbol}
                {monthSales.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
              <div className="text-xs text-slate-400 font-bold uppercase">Monthly Collections</div>
              <div className="text-xl font-black text-emerald-700 mt-1">
                {settings.currencySymbol}
                {monthCollection.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>
      )}

      {reportTab === 'pending' && (
        <div className="space-y-4">
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <div className="text-xs text-rose-700 font-bold uppercase">Total Pending Credit</div>
              <div className="text-2xl font-black text-rose-900">
                {settings.currencySymbol}
                {totalPendingSum.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="text-right text-xs font-bold text-rose-800">
              {pendingCustomers.length} Pending Customers
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
            <div className="divide-y divide-slate-100 text-xs">
              {pendingCustomers.map((c) => (
                <div key={c.customerId} className="py-3 flex items-center justify-between">
                  <div>
                    <div className="font-extrabold text-slate-900 text-sm">{c.customerName}</div>
                    <div className="text-slate-400 text-[11px]">{c.phone || 'No phone'} • {c.groupName}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-rose-600 text-sm">
                      {settings.currencySymbol}{c.currentBalance.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {reportTab === 'customer' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
          <h3 className="font-extrabold text-slate-900 text-sm mb-3">Customer Balance Breakdown</h3>
          <div className="divide-y divide-slate-100 text-xs">
            {activeCustomers.map((c) => (
              <div key={c.customerId} className="py-2.5 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-800">{c.customerName}</div>
                  <div className="text-[11px] text-slate-400">{c.groupName}</div>
                </div>
                <div className="text-right">
                  <div className={`font-black ${c.currentBalance > 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                    {settings.currencySymbol}{c.currentBalance.toLocaleString('en-IN')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
