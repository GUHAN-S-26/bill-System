import React, { useState } from 'react';
import {
  Search,
  UserPlus,
  Phone,
  Receipt,
  CreditCard,
  FileText,
  MoreVertical,
  Users,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Customer } from '../../types';

interface CustomerListViewProps {
  onSelectCustomer: (customerId: string) => void;
  onOpenAddCustomer: () => void;
  onOpenCreateBillForCustomer: (customer: Customer) => void;
  onOpenReceivePaymentForCustomer: (customer: Customer) => void;
  onOpenManageGroups: () => void;
}

export const CustomerListView: React.FC<CustomerListViewProps> = ({
  onSelectCustomer,
  onOpenAddCustomer,
  onOpenCreateBillForCustomer,
  onOpenReceivePaymentForCustomer,
  onOpenManageGroups,
}) => {
  const { customers, groups, settings } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('ALL');

  const activeCustomers = customers.filter((c) => !c.isDeleted && c.isActive);

  const filteredCustomers = activeCustomers.filter((c) => {
    const matchesGroup = selectedGroupId === 'ALL' || c.groupId === selectedGroupId;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      c.customerName.toLowerCase().includes(q) || (c.phone && c.phone.includes(q));
    return matchesGroup && matchesSearch;
  });

  const getInitials = (name: string) => {
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  const totalOutstandingAll = activeCustomers.reduce(
    (sum, c) => sum + Math.max(0, c.currentBalance),
    0
  );

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">Customers Directory</h1>
          <p className="text-xs text-slate-500 font-medium">
            Total Outstanding Credit: <span className="text-rose-600 font-bold">{settings.currencySymbol}{totalOutstandingAll.toLocaleString('en-IN')}</span>
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenManageGroups}
            className="p-2 text-slate-600 hover:text-emerald-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-2xs"
            title="Manage Groups"
          >
            <Users className="w-5 h-5" />
          </button>
          <button
            onClick={onOpenAddCustomer}
            className="flex items-center space-x-1.5 bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-2xs hover:bg-emerald-800 transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search customer name or phone number..."
          className="w-full bg-white border border-slate-200 pl-10 pr-4 py-2.5 rounded-xl text-sm focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 text-slate-900 placeholder-slate-400 shadow-2xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
          >
            Clear
          </button>
        )}
      </div>

      {/* Group Filter Chips */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs no-scrollbar">
        <button
          onClick={() => setSelectedGroupId('ALL')}
          className={`px-3.5 py-1.5 rounded-full font-bold whitespace-nowrap transition-colors ${
            selectedGroupId === 'ALL'
              ? 'bg-emerald-700 text-white shadow-2xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          All ({activeCustomers.length})
        </button>
        {groups
          .filter((g) => !g.isDeleted)
          .map((g) => {
            const count = activeCustomers.filter((c) => c.groupId === g.groupId).length;
            return (
              <button
                key={g.groupId}
                onClick={() => setSelectedGroupId(g.groupId)}
                className={`px-3.5 py-1.5 rounded-full font-bold whitespace-nowrap transition-colors ${
                  selectedGroupId === g.groupId
                    ? 'bg-emerald-700 text-white shadow-2xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {g.groupName} ({count})
              </button>
            );
          })}
      </div>

      {/* Customer Cards List */}
      <div className="space-y-3">
        {filteredCustomers.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <div className="font-bold text-slate-700 text-base">No customers found</div>
            <p className="text-xs text-slate-400 mt-1">Try searching for a different name or group filter.</p>
            <button
              onClick={onOpenAddCustomer}
              className="mt-4 bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs"
            >
              Add New Customer
            </button>
          </div>
        ) : (
          filteredCustomers.map((customer) => {
            const hasPending = customer.currentBalance > 0;

            return (
              <div
                key={customer.customerId}
                className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-2xs hover:border-emerald-300 transition-colors"
              >
                <div
                  onClick={() => onSelectCustomer(customer.customerId)}
                  className="cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-100/80 text-emerald-800 font-black text-base flex items-center justify-center shrink-0 border border-emerald-200/50">
                        {getInitials(customer.customerName)}
                      </div>
                      <div>
                        <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                          {customer.customerName}
                        </h3>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                          {customer.phone ? (
                            <span className="flex items-center gap-1 font-medium text-slate-600">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {customer.phone}
                            </span>
                          ) : (
                            <span className="text-slate-400">No Phone</span>
                          )}
                          <span className="inline-block w-1 h-1 rounded-full bg-slate-300"></span>
                          <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-semibold text-[10px]">
                            {customer.groupName}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Balance Status Pill */}
                    <div className="text-right">
                      <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                        Pending Balance
                      </div>
                      <div
                        className={`text-base font-black ${
                          hasPending ? 'text-rose-600' : 'text-emerald-600'
                        }`}
                      >
                        {settings.currencySymbol}
                        {Math.abs(customer.currentBalance).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Financial Stats Bar */}
                  <div className="mt-3 bg-slate-50 rounded-xl p-2.5 flex items-center justify-between text-xs border border-slate-100">
                    <div>
                      <span className="text-slate-400 font-medium">Total Bills: </span>
                      <span className="font-bold text-slate-800">
                        {settings.currencySymbol}
                        {customer.totalPurchase.toLocaleString('en-IN')}
                      </span>
                    </div>
                    <div className="h-3 w-px bg-slate-200"></div>
                    <div>
                      <span className="text-slate-400 font-medium">Total Paid: </span>
                      <span className="font-bold text-emerald-700">
                        {settings.currencySymbol}
                        {customer.totalPaid.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Quick Action Bar */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
                  <button
                    onClick={() => onOpenCreateBillForCustomer(customer)}
                    className="flex-1 flex items-center justify-center space-x-1 py-1.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 font-bold rounded-lg transition-colors border border-emerald-200/60"
                  >
                    <Receipt className="w-3.5 h-3.5" />
                    <span>Bill</span>
                  </button>

                  <button
                    onClick={() => onOpenReceivePaymentForCustomer(customer)}
                    className="flex-1 flex items-center justify-center space-x-1 py-1.5 bg-blue-50 text-blue-800 hover:bg-blue-100 font-bold rounded-lg transition-colors border border-blue-200/60"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Payment</span>
                  </button>

                  <button
                    onClick={() => onSelectCustomer(customer.customerId)}
                    className="flex-1 flex items-center justify-center space-x-1 py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 font-bold rounded-lg transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Statement</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
