import React, { useState, useEffect } from 'react';
import { X, UserPlus, Save, Users, Plus, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Customer } from '../../types';

interface AddEditCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerToEdit?: Customer | null;
  onCustomerSaved?: (customer: Customer) => void;
}

export const AddEditCustomerModal: React.FC<AddEditCustomerModalProps> = ({
  isOpen,
  onClose,
  customerToEdit,
  onCustomerSaved,
}) => {
  const { groups, addGroup, addCustomer, updateCustomer, settings } = useApp();

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [groupId, setGroupId] = useState('');
  const [openingBalance, setOpeningBalance] = useState<number>(0);
  const [remarks, setRemarks] = useState('');
  const [error, setError] = useState('');

  const [showCreateGroupInput, setShowCreateGroupInput] = useState(false);
  const [newGroupNameInput, setNewGroupNameInput] = useState('');

  useEffect(() => {
    if (customerToEdit) {
      setCustomerName(customerToEdit.customerName);
      setPhone(customerToEdit.phone || '');
      setGroupId(customerToEdit.groupId);
      setOpeningBalance(customerToEdit.openingBalance || 0);
      setRemarks(customerToEdit.remarks || '');
    } else {
      setCustomerName('');
      setPhone('');
      const defaultGrp = groups.find((g) => g.groupId === settings.defaultGroupId) || groups[0];
      setGroupId(defaultGrp?.groupId || '');
      setOpeningBalance(0);
      setRemarks('');
    }
    setError('');
    setShowCreateGroupInput(false);
    setNewGroupNameInput('');
  }, [customerToEdit, isOpen, groups, settings]);

  if (!isOpen) return null;

  const handleGroupSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    if (val === '__CREATE_NEW__') {
      setShowCreateGroupInput(true);
    } else {
      setGroupId(val);
      setShowCreateGroupInput(false);
    }
  };

  const handleCreateGroup = () => {
    if (!newGroupNameInput.trim()) return;
    const created = addGroup(newGroupNameInput.trim());
    setGroupId(created.groupId);
    setNewGroupNameInput('');
    setShowCreateGroupInput(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      setError('Customer name is required.');
      return;
    }

    const selectedGroupObj = groups.find((g) => g.groupId === groupId) || groups[0];

    if (customerToEdit) {
      updateCustomer(customerToEdit.customerId, {
        customerName: customerName.trim(),
        phone: phone.trim(),
        groupId: selectedGroupObj.groupId,
        groupName: selectedGroupObj.groupName,
        openingBalance: Number(openingBalance) || 0,
        remarks: remarks.trim(),
      });
      onClose();
    } else {
      const created = addCustomer({
        customerName: customerName.trim(),
        phone: phone.trim(),
        groupId: selectedGroupObj.groupId,
        groupName: selectedGroupObj.groupName,
        openingBalance: Number(openingBalance) || 0,
        remarks: remarks.trim(),
      });
      if (onCustomerSaved) onCustomerSaved(created);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center space-x-2">
            <UserPlus className="w-5 h-5 text-emerald-700" />
            <h3 className="font-extrabold text-slate-800 text-base">
              {customerToEdit ? 'Edit Customer Details' : 'Add New Customer'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold">
              {error}
            </div>
          )}

          {/* Customer Name */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">
              Customer Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="e.g. Ramesh Kumar / Meena Stores"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
              required
            />
          </div>

          {/* Phone Number */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">Phone Number (Optional)</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="e.g. 9876543210"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
          </div>

          {/* Customer Group Selector */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">Customer Group</label>
            <select
              value={showCreateGroupInput ? '__CREATE_NEW__' : groupId}
              onChange={handleGroupSelectChange}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            >
              {groups
                .filter((g) => !g.isDeleted)
                .map((g) => (
                  <option key={g.groupId} value={g.groupId}>
                    {g.groupName}
                  </option>
                ))}
              <option value="__CREATE_NEW__">+ Create New Group</option>
            </select>

            {showCreateGroupInput ? (
              <div className="mt-2.5 bg-emerald-50/80 border border-emerald-200 rounded-xl p-3 space-y-2 animate-in fade-in duration-150">
                <div className="text-xs font-bold text-emerald-900">Enter New Group Name</div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newGroupNameInput}
                    onChange={(e) => setNewGroupNameInput(e.target.value)}
                    placeholder="e.g. VIP, Wholesale, Retail"
                    className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleCreateGroup();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleCreateGroup}
                    className="bg-emerald-700 text-white hover:bg-emerald-800 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 shrink-0"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCreateGroupInput(false);
                      setNewGroupNameInput('');
                    }}
                    className="text-slate-500 hover:text-slate-700 px-2 py-2 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between mt-1.5 px-0.5">
                <button
                  type="button"
                  onClick={() => setShowCreateGroupInput(true)}
                  className="text-emerald-700 hover:text-emerald-800 font-bold text-xs flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create New Group</span>
                </button>
              </div>
            )}
          </div>

          {/* Opening Balance */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">
              Opening Credit Balance ({settings.currencySymbol})
            </label>
            <input
              type="number"
              value={openingBalance}
              onChange={(e) => setOpeningBalance(parseFloat(e.target.value) || 0)}
              placeholder="0.00"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
            <p className="text-[10px] text-slate-400 mt-1">
              Initial pending credit balance owed by customer before using this app.
            </p>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">Remarks / Notes</label>
            <textarea
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Weekly payer, regular credit buyer..."
              rows={2}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-medium text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
          </div>

          {/* Submit */}
          <div className="pt-3 flex items-center space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 text-slate-600 bg-slate-100 hover:bg-slate-200 font-bold rounded-xl text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center space-x-2 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>{customerToEdit ? 'Save Changes' : 'Create Customer'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
