import React, { useState } from 'react';
import {
  ArrowLeft,
  Phone,
  FileDown,
  Receipt,
  CreditCard,
  Edit2,
  Trash2,
  Tag,
  Clock,
  CheckCircle,
  AlertCircle,
  Calendar,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Customer, Bill, Payment } from '../../types';
import { generateCustomerStatementPDF } from '../../services/pdfGenerator';
import { formatDate } from '../../utils/dateUtils';

interface CustomerDetailViewProps {
  customerId: string;
  onBack: () => void;
  onOpenCreateBill: (customer: Customer) => void;
  onOpenReceivePayment: (customer: Customer) => void;
  onOpenEditCustomer: (customer: Customer) => void;
  onOpenBillDetail: (bill: Bill) => void;
  onOpenPaymentDetail?: (payment: Payment) => void;
}

export const CustomerDetailView: React.FC<CustomerDetailViewProps> = ({
  customerId,
  onBack,
  onOpenCreateBill,
  onOpenReceivePayment,
  onOpenEditCustomer,
  onOpenBillDetail,
  onOpenPaymentDetail,
}) => {
  const { customers, settings, getCustomerStatement, deleteCustomer } = useApp();

  const customer = customers.find((c) => c.customerId === customerId);

  if (!customer) {
    return (
      <div className="p-8 text-center max-w-lg mx-auto">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-2" />
        <h2 className="font-bold text-slate-800 text-lg">Customer not found</h2>
        <button
          onClick={onBack}
          className="mt-4 bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl"
        >
          Return to Customers List
        </button>
      </div>
    );
  }

  const statementItems = getCustomerStatement(customerId);

  const handleExportPDF = () => {
    generateCustomerStatementPDF(settings, customer, statementItems);
  };

  const handleDelete = () => {
    if (
      window.confirm(
        `Are you sure you want to soft-delete customer "${customer.customerName}"?`
      )
    ) {
      deleteCustomer(customer.customerId);
      onBack();
    }
  };

  const getInitials = (name: string) => {
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Top Header Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-slate-600 hover:text-slate-900 font-bold text-sm bg-white border border-slate-200 px-3 py-1.5 rounded-xl shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onOpenEditCustomer(customer)}
            className="p-2 text-slate-600 hover:text-emerald-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-2xs"
            title="Edit Customer"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={handleDelete}
            className="p-2 text-rose-600 hover:text-rose-700 bg-white border border-rose-200 rounded-xl hover:bg-rose-50 transition-colors shadow-2xs"
            title="Delete Customer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportPDF}
            className="flex items-center space-x-1.5 bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-2xs hover:bg-emerald-800 transition-colors"
          >
            <FileDown className="w-4 h-4" />
            <span>PDF Statement</span>
          </button>
        </div>
      </div>

      {/* Customer Main Info Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-800 font-black text-xl flex items-center justify-center shrink-0 border border-emerald-200">
              {getInitials(customer.customerName)}
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-900">{customer.customerName}</h1>
              <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                {customer.phone && (
                  <a
                    href={`tel:${customer.phone}`}
                    className="flex items-center gap-1 text-emerald-700 font-semibold hover:underline"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    {customer.phone}
                  </a>
                )}
                <span className="bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full font-bold text-[11px] flex items-center gap-1">
                  <Tag className="w-3 h-3 text-slate-400" />
                  {customer.groupName}
                </span>
              </div>
              {customer.remarks && (
                <p className="text-xs text-slate-500 mt-1 italic">"{customer.remarks}"</p>
              )}
            </div>
          </div>
        </div>

        {/* Quick Transaction Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-100">
          <button
            onClick={() => onOpenCreateBill(customer)}
            className="flex items-center justify-center space-x-2 py-2.5 bg-emerald-700 text-white font-bold rounded-xl text-sm shadow-xs hover:bg-emerald-800 transition-colors"
          >
            <Receipt className="w-4 h-4" />
            <span>Create Bill</span>
          </button>
          <button
            onClick={() => onOpenReceivePayment(customer)}
            className="flex items-center justify-center space-x-2 py-2.5 bg-blue-600 text-white font-bold rounded-xl text-sm shadow-xs hover:bg-blue-700 transition-colors"
          >
            <CreditCard className="w-4 h-4" />
            <span>Receive Payment</span>
          </button>
        </div>
      </div>

      {/* Financial Overview Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[11px] text-slate-400 font-semibold uppercase">Opening Balance</div>
          <div className="text-base font-extrabold text-slate-800 mt-0.5">
            {settings.currencySymbol}
            {customer.openingBalance.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[11px] text-slate-400 font-semibold uppercase">Total Purchase</div>
          <div className="text-base font-extrabold text-slate-800 mt-0.5">
            {settings.currencySymbol}
            {customer.totalPurchase.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[11px] text-slate-400 font-semibold uppercase">Total Paid</div>
          <div className="text-base font-extrabold text-emerald-700 mt-0.5">
            {settings.currencySymbol}
            {customer.totalPaid.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-3.5 shadow-2xs bg-rose-50/50">
          <div className="text-[11px] text-rose-600 font-bold uppercase">Net Pending</div>
          <div className="text-lg font-black text-rose-600 mt-0.5">
            {settings.currencySymbol}
            {customer.currentBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
        </div>
      </div>

      {/* Statement Running Balance Timeline Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-extrabold text-slate-900 text-base">Running Balance Statement</h2>
          <span className="text-xs text-slate-500 font-medium">
            {statementItems.length} transactions
          </span>
        </div>

        {statementItems.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-sm">No transaction records found for this customer.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold">
                  <th className="py-2.5 px-3 rounded-l-lg">Date</th>
                  <th className="py-2.5 px-3">Ref / Type</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-right text-slate-900">Debit (+)</th>
                  <th className="py-2.5 px-3 text-right text-emerald-700">Credit (-)</th>
                  <th className="py-2.5 px-3 text-right rounded-r-lg">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {statementItems.map((item) => {
                  const formattedDate = formatDate(item.date);

                  return (
                    <tr
                      key={item.id}
                      onClick={() => {
                        if (item.type === 'bill' && item.rawItem) {
                          onOpenBillDetail(item.rawItem as Bill);
                        } else if (item.type === 'payment' && item.rawItem && onOpenPaymentDetail) {
                          onOpenPaymentDetail(item.rawItem as Payment);
                        }
                      }}
                      className={`hover:bg-slate-50 transition-colors cursor-pointer`}
                    >
                      <td className="py-3 px-3 text-slate-500 whitespace-nowrap">{formattedDate}</td>
                      <td className="py-3 px-3 font-semibold text-slate-800 whitespace-nowrap">
                        {item.refNumber}
                      </td>
                      <td className="py-3 px-3 text-slate-600 max-w-[200px] truncate">
                        {item.description}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-slate-900 whitespace-nowrap">
                        {item.debit > 0 ? `${settings.currencySymbol}${item.debit.toLocaleString('en-IN')}` : '-'}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-emerald-700 whitespace-nowrap">
                        {item.credit > 0 ? `${settings.currencySymbol}${item.credit.toLocaleString('en-IN')}` : '-'}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-slate-900 whitespace-nowrap">
                        {settings.currencySymbol}
                        {item.runningBalance.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
