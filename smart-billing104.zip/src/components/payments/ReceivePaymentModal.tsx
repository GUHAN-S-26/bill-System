import React, { useState, useEffect } from 'react';
import { X, CreditCard, CheckCircle2, Wallet, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Customer, PaymentMethod, Payment } from '../../types';

interface ReceivePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedCustomer?: Customer | null;
  onPaymentSaved?: (payment: Payment) => void;
}

export const ReceivePaymentModal: React.FC<ReceivePaymentModalProps> = ({
  isOpen,
  onClose,
  preSelectedCustomer,
  onPaymentSaved,
}) => {
  const { customers, addPayment, settings } = useApp();

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [amount, setAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [remarks, setRemarks] = useState('');
  const [error, setError] = useState('');

  const activeCustomers = customers.filter((c) => !c.isDeleted && c.isActive);

  useEffect(() => {
    if (preSelectedCustomer) {
      setSelectedCustomerId(preSelectedCustomer.customerId);
      setAmount(Math.max(0, preSelectedCustomer.currentBalance));
    } else if (activeCustomers.length > 0) {
      setSelectedCustomerId(activeCustomers[0].customerId);
      setAmount(Math.max(0, activeCustomers[0].currentBalance));
    }
    setPaymentMethod('cash');
    setRemarks('');
    setError('');
  }, [preSelectedCustomer, isOpen]);

  if (!isOpen) return null;

  const currentCustomer = activeCustomers.find((c) => c.customerId === selectedCustomerId);

  const handleCustomerChange = (cid: string) => {
    setSelectedCustomerId(cid);
    const cust = activeCustomers.find((c) => c.customerId === cid);
    if (cust) {
      setAmount(Math.max(0, cust.currentBalance));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCustomer) {
      setError('Please select a valid customer.');
      return;
    }

    if (!amount || amount <= 0) {
      setError('Payment amount must be greater than zero.');
      return;
    }

    const newPay = addPayment({
      customerId: currentCustomer.customerId,
      customerName: currentCustomer.customerName,
      groupId: currentCustomer.groupId,
      groupName: currentCustomer.groupName,
      amount: Number(amount),
      paymentMethod,
      remarks: remarks.trim(),
    });

    if (onPaymentSaved) onPaymentSaved(newPay);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <h3 className="font-extrabold text-slate-800 text-base">Receive Payment</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold">
              {error}
            </div>
          )}

          {/* Customer Selector */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">
              Select Customer <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => handleCustomerChange(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-blue-600 focus:bg-white"
            >
              {activeCustomers.map((c) => (
                <option key={c.customerId} value={c.customerId}>
                  {c.customerName} ({c.groupName}) - Pending: {settings.currencySymbol}
                  {c.currentBalance.toLocaleString('en-IN')}
                </option>
              ))}
            </select>
          </div>

          {/* Outstanding Balance Banner */}
          {currentCustomer && (
            <div className="bg-blue-50/80 border border-blue-200 rounded-2xl p-3.5 flex items-center justify-between">
              <div>
                <div className="text-[11px] font-bold text-blue-800 uppercase">
                  Current Outstanding Balance
                </div>
                <div className="text-xl font-black text-rose-600">
                  {settings.currencySymbol}
                  {currentCustomer.currentBalance.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                  })}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAmount(Math.max(0, currentCustomer.currentBalance))}
                className="bg-blue-600 text-white font-bold text-xs px-3 py-1.5 rounded-xl hover:bg-blue-700 shadow-xs"
              >
                Clear Full
              </button>
            </div>
          )}

          {/* Payment Amount Input */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">
              Amount Received ({settings.currencySymbol}) <span className="text-rose-500">*</span>
            </label>
            <input
              type="number"
              value={amount || ''}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              placeholder="0.00"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-3 text-lg font-black text-slate-900 focus:outline-hidden focus:border-blue-600 focus:bg-white"
              required
            />

            {/* Quick Chips */}
            <div className="flex items-center space-x-2 mt-2">
              <button
                type="button"
                onClick={() => setAmount(500)}
                className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg font-bold text-xs hover:bg-slate-200"
              >
                ₹500
              </button>
              <button
                type="button"
                onClick={() => setAmount(1000)}
                className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg font-bold text-xs hover:bg-slate-200"
              >
                ₹1,000
              </button>
              <button
                type="button"
                onClick={() => setAmount(2000)}
                className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg font-bold text-xs hover:bg-slate-200"
              >
                ₹2,000
              </button>
              <button
                type="button"
                onClick={() => setAmount(5000)}
                className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg font-bold text-xs hover:bg-slate-200"
              >
                ₹5,000
              </button>
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">Payment Method</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPaymentMethod('cash')}
                className={`py-2 px-2.5 rounded-xl border text-xs font-bold transition-colors ${
                  paymentMethod === 'cash'
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                💵 Cash
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('upi')}
                className={`py-2 px-2.5 rounded-xl border text-xs font-bold transition-colors ${
                  paymentMethod === 'upi'
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                📱 PhonePe / UPI
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('bank_transfer')}
                className={`py-2 px-2.5 rounded-xl border text-xs font-bold transition-colors ${
                  paymentMethod === 'bank_transfer'
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                🏦 Bank / Cheque
              </button>
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">Transaction Remarks / Ref</label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Received by cash at counter / UPI Tx ID"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-medium text-slate-900 focus:outline-hidden focus:border-blue-600"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 text-slate-600 bg-slate-100 hover:bg-slate-200 font-bold rounded-xl text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center space-x-2 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-sm rounded-xl shadow-xs transition-colors"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>Record Payment</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
