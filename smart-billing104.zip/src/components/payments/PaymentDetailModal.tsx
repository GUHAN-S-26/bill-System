import React from 'react';
import { X, Printer, Trash2, CreditCard, Share2, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Payment } from '../../types';
import { formatDateTime } from '../../utils/dateUtils';

interface PaymentDetailModalProps {
  payment: Payment | null;
  onClose: () => void;
}

export const PaymentDetailModal: React.FC<PaymentDetailModalProps> = ({ payment, onClose }) => {
  const { settings, deletePayment } = useApp();

  if (!payment) return null;

  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete Payment receipt #${payment.paymentId}?`)) {
      deletePayment(payment.paymentId);
      onClose();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppShare = () => {
    const text = `*${settings.shopName}*\n\nPayment Receipt\nReceipt #: ${payment.paymentId}\nCustomer: ${payment.customerName}\nAmount Received: ${settings.currencySymbol}${payment.amount}\nMode: ${payment.paymentMethod.toUpperCase()}\nDate: ${formatDateTime(payment.createdAt)}\nRemarks: ${payment.remarks || 'None'}\n\nThank you for your payment!`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-blue-50">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-blue-700" />
            <h3 className="font-extrabold text-slate-800 text-base">Payment Receipt #{payment.paymentId}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Body */}
        <div className="p-5 space-y-4 overflow-y-auto text-xs flex-1" id="printable-payment-receipt">
          {/* Shop Header */}
          <div className="text-center pb-3 border-b border-slate-200">
            <h2 className="font-extrabold text-lg text-slate-900">{settings.shopName}</h2>
            <p className="text-slate-500">{settings.address}</p>
            <p className="text-slate-500 font-semibold">Ph: {settings.phone}</p>
          </div>

          {/* Success Banner */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-1" />
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-wide">Payment Successfully Received</div>
            <div className="text-2xl font-black text-emerald-950 mt-1">
              {settings.currencySymbol}{payment.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
          </div>

          {/* Details Card */}
          <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400 font-medium">Customer:</span>
              <span className="font-extrabold text-slate-900">{payment.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-medium">Group:</span>
              <span className="font-bold text-slate-700">{payment.groupName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-medium">Payment Mode:</span>
              <span className="font-bold text-blue-700 uppercase bg-blue-100 px-2 py-0.5 rounded text-[10px]">
                {payment.paymentMethod}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-medium">Date & Time:</span>
              <span className="font-semibold text-slate-800">{formatDateTime(payment.createdAt)}</span>
            </div>
            {payment.remarks && (
              <div className="flex justify-between border-t border-slate-200 pt-1.5 mt-1.5">
                <span className="text-slate-400 font-medium">Remarks:</span>
                <span className="font-medium text-slate-800 italic">{payment.remarks}</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-2">
          <button
            onClick={handleDelete}
            className="p-2.5 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors"
            title="Delete Payment"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleWhatsAppShare}
              className="px-3 py-2.5 bg-emerald-600 text-white hover:bg-emerald-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-2.5 bg-slate-800 text-white hover:bg-slate-900 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Printer className="w-4 h-4" />
              <span>Print</span>
            </button>
            <button
              onClick={onClose}
              className="px-3 py-2.5 bg-slate-200 text-slate-800 hover:bg-slate-300 font-bold rounded-xl text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
