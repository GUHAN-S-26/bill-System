import React, { useState, useEffect } from 'react';
import {
  Store,
  User,
  Shield,
  LogOut,
  Save,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  KeyRound,
  Lock,
  Loader2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface SettingsViewProps {
  onBack: () => void;
  onOpenAuditLogs: () => void;
  onLogout: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onBack,
  onOpenAuditLogs,
  onLogout,
}) => {
  const { settings, updateSettings, user, resetAllData, changePassword } = useApp();

  const [shopName, setShopName] = useState(settings.shopName);
  const [ownerName, setOwnerName] = useState(settings.ownerName);
  const [phone, setPhone] = useState(settings.phone);
  const [address, setAddress] = useState(settings.address);
  const [upiId, setUpiId] = useState(settings.upiId);
  const [savedMessage, setSavedMessage] = useState(false);

  // Password Change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [pwdSuccessMsg, setPwdSuccessMsg] = useState('');
  const [pwdErrorMsg, setPwdErrorMsg] = useState('');

  useEffect(() => {
    setShopName(settings.shopName);
    setOwnerName(settings.ownerName);
    setPhone(settings.phone);
    setAddress(settings.address);
    setUpiId(settings.upiId);
  }, [settings.shopName, settings.ownerName, settings.phone, settings.address, settings.upiId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      shopName: shopName.trim(),
      ownerName: ownerName.trim(),
      phone: phone.trim(),
      address: address.trim(),
      upiId: upiId.trim(),
    });
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 3000);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdSuccessMsg('');
    setPwdErrorMsg('');

    if (!currentPassword.trim()) {
      setPwdErrorMsg('Please enter your current password.');
      return;
    }

    if (!newPassword.trim()) {
      setPwdErrorMsg('Please enter a new password.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPwdErrorMsg('New password and confirmation do not match.');
      return;
    }

    setIsChangingPassword(true);
    const result = await changePassword(currentPassword.trim(), newPassword.trim());
    setIsChangingPassword(false);

    if (result.success) {
      setPwdSuccessMsg(result.message);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } else {
      setPwdErrorMsg(result.message);
    }
  };

  const handleResetData = () => {
    if (
      window.confirm(
        'Are you sure you want to reset all shop data back to initial demo state? This will clear all custom added customers and bills.'
      )
    ) {
      resetAllData();
      alert('Shop database restored to initial sample state.');
      onBack();
    }
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-slate-600 hover:text-slate-900 font-bold text-sm bg-white border border-slate-200 px-3 py-1.5 rounded-xl shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h1 className="text-lg font-black text-slate-900">Shop Settings</h1>
        <div className="w-16"></div>
      </div>

      {savedMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Shop settings updated successfully!</span>
        </div>
      )}

      {/* Shop Info Form */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
        <h2 className="font-extrabold text-slate-900 text-base mb-4 flex items-center gap-2">
          <Store className="w-5 h-5 text-emerald-700" />
          <span>Single Shop Profile ({settings.shopName || 'Shankar Shop'})</span>
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-700 font-bold mb-1">Shop Name</label>
            <input
              type="text"
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-bold mb-1">Owner Name</label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-bold mb-1">Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-bold mb-1">Shop Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-medium text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-bold mb-1">Shop UPI ID (For Receipt Payments)</label>
            <input
              type="text"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              placeholder="e.g. shankarshop@upi"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center space-x-2 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-xs transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Shop Details</span>
          </button>
        </form>
      </div>

      {/* Owner Firebase Account & Password Change Section */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-indigo-600" />
              <span>Firebase Owner Authentication & Password</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Logged in as <span className="font-bold text-slate-800">{user?.name || user?.username}</span> ({user?.username}@shankarshop.com)
            </p>
          </div>
          <span className="px-2.5 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-extrabold rounded-lg">
            Active Owner Account
          </span>
        </div>

        <p className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
          🔒 Each user can strictly change only their own password. Changing password updates your account credentials in Firebase Authentication immediately.
        </p>

        {/* Notifications */}
        {pwdSuccessMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center space-x-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{pwdSuccessMsg}</span>
          </div>
        )}

        {pwdErrorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center space-x-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{pwdErrorMsg}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-700 font-bold mb-1">Current Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter current password (e.g. 2003)"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-indigo-600 focus:bg-white"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-bold mb-1">New Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-indigo-600 focus:bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Confirm New Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-slate-900 focus:outline-hidden focus:border-indigo-600 focus:bg-white"
                  required
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isChangingPassword}
            className="w-full flex items-center justify-center space-x-2 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors disabled:opacity-60"
          >
            {isChangingPassword ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Updating Firebase Auth Password...</span>
              </>
            ) : (
              <>
                <KeyRound className="w-4 h-4" />
                <span>Update Password in Firebase</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Audit Log & Security Link */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">Audit Trail & Security Logs</h3>
            <p className="text-xs text-slate-500">Track all logins, password changes, and edits.</p>
          </div>
        </div>

        <button
          onClick={onOpenAuditLogs}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-2xs"
        >
          View Audit Logs
        </button>
      </div>

      {/* Flutter Mobile (Android) & Desktop App Build/Download Card */}
      <div className="bg-emerald-950 text-white border border-emerald-800 rounded-2xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-black">
              📱
            </div>
            <div>
              <h3 className="font-extrabold text-white text-sm">Flutter Android App & Windows Desktop</h3>
              <p className="text-xs text-emerald-300">Complete recreated Flutter project is ready in <code className="bg-emerald-900/80 px-1.5 py-0.5 rounded text-[11px]">/flutter_app</code></p>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold rounded-lg uppercase tracking-wider">
            Ready
          </span>
        </div>

        <div className="text-xs text-emerald-100 bg-emerald-900/50 p-3 rounded-xl border border-emerald-800/80 space-y-1.5">
          <p className="font-bold text-white">How to download & build Android APK:</p>
          <ol className="list-decimal list-inside space-y-1 text-[11px] text-emerald-200">
            <li>Click <strong>Export / Download ZIP</strong> from top right menu of AI Studio.</li>
            <li>Extract the downloaded project folder and navigate to <code className="bg-emerald-900 px-1 rounded">flutter_app</code>.</li>
            <li>Run <code className="bg-emerald-900 px-1 rounded text-emerald-300">flutter pub get</code></li>
            <li>Build release APK: <code className="bg-emerald-900 px-1 rounded text-emerald-300">flutter build apk --release</code></li>
            <li>Install <code className="bg-emerald-900 px-1 rounded text-emerald-300">app-release.apk</code> on your Android phone!</li>
          </ol>
        </div>
      </div>

      {/* Danger Zone: Reset Data */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
        <div>
          <h3 className="font-extrabold text-rose-600 text-sm">Reset Sample Demo Data</h3>
          <p className="text-xs text-slate-500">Re-populate sample customers, bills, and payment records.</p>
        </div>

        <button
          onClick={handleResetData}
          className="px-3.5 py-2 bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 font-bold text-xs rounded-xl transition-colors"
        >
          Reset Data
        </button>
      </div>

      {/* Logout */}
      <button
        onClick={onLogout}
        className="w-full flex items-center justify-center space-x-2 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-colors"
      >
        <LogOut className="w-4 h-4" />
        <span>Logout Owner Session ({user?.username})</span>
      </button>
    </div>
  );
};
