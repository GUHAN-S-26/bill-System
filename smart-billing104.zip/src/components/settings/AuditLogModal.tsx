import React, { useState } from 'react';
import { X, Shield, Clock, Search, Filter, UserCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({ isOpen, onClose }) => {
  const { auditLogs } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOwner, setSelectedOwner] = useState('all');
  const [selectedModule, setSelectedModule] = useState('all');

  if (!isOpen) return null;

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      (log.ownerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.ownerEmail || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.action || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.module || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.recordId || '').toLowerCase().includes(searchTerm.toLowerCase());

    const matchesOwner =
      selectedOwner === 'all' ||
      (log.ownerName || '').toLowerCase() === selectedOwner.toLowerCase();

    const matchesModule =
      selectedModule === 'all' ||
      (log.module || '').toLowerCase() === selectedModule.toLowerCase();

    return matchesSearch && matchesOwner && matchesModule;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-purple-100 flex items-center justify-center text-purple-700">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-800 text-base">Shankar Shop Audit Trail</h3>
              <p className="text-xs text-slate-500">
                Detailed record of all owner operations and system activities
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Controls */}
        <div className="p-4 border-b border-slate-200 bg-white grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="flex items-center space-x-2">
            <UserCheck className="w-4 h-4 text-slate-400" />
            <select
              value={selectedOwner}
              onChange={(e) => setSelectedOwner(e.target.value)}
              className="w-full py-1.5 px-3 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="all">All Owners</option>
              <option value="venkatesh">Venkatesh</option>
              <option value="priya">Priya</option>
              <option value="deepika">Deepika</option>
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={selectedModule}
              onChange={(e) => setSelectedModule(e.target.value)}
              className="w-full py-1.5 px-3 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="all">All Modules</option>
              <option value="authentication">Authentication</option>
              <option value="shop settings">Shop Settings</option>
              <option value="billing">Billing</option>
              <option value="customers">Customers</option>
              <option value="payments">Payments</option>
              <option value="groups">Groups</option>
            </select>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto flex-1 p-4 bg-slate-50">
          {filteredLogs.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <Clock className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              No audit logs match your search criteria.
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                    <th className="py-2.5 px-3">Date & Time</th>
                    <th className="py-2.5 px-3">Owner Name</th>
                    <th className="py-2.5 px-3">Email</th>
                    <th className="py-2.5 px-3">Action Performed</th>
                    <th className="py-2.5 px-3">Module</th>
                    <th className="py-2.5 px-3">Record ID</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredLogs.map((log) => (
                    <tr key={log.logId} className="hover:bg-purple-50/50 transition-colors">
                      <td className="py-2.5 px-3 font-medium whitespace-nowrap text-slate-500">
                        {log.dateTime || new Date(log.performedAt).toLocaleString('en-IN')}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-slate-900">
                        {log.ownerName || log.performedBy || 'Owner'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                        {log.ownerEmail || `${(log.ownerName || 'owner').toLowerCase()}@shankarshop.com`}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-purple-900">
                        {log.action}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                          {log.module || log.entityType || 'System'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                        {log.recordId || log.entityId || 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-white flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredLogs.length} of {auditLogs.length} entries
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
