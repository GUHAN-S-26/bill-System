import React, { useState } from 'react';
import { X, Users, Plus, Edit2, Trash2, Check, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface GroupManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GroupManagementModal: React.FC<GroupManagementModalProps> = ({ isOpen, onClose }) => {
  const { groups, addGroup, renameGroup, deleteGroup, customers } = useApp();

  const [newGroupName, setNewGroupName] = useState('');
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [confirmDeleteGroup, setConfirmDeleteGroup] = useState<{ id: string; name: string; count: number } | null>(null);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [deletingGroupId, setDeletingGroupId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) {
      setError('Group name is required.');
      return;
    }
    addGroup(newGroupName.trim());
    setNewGroupName('');
    setError('');
    setSuccessMessage(`Group "${newGroupName.trim()}" created successfully!`);
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleStartRename = (groupId: string, currentName: string) => {
    setEditingGroupId(groupId);
    setEditName(currentName);
    setError('');
    setSuccessMessage('');
  };

  const handleSaveRename = (groupId: string) => {
    if (!editName.trim()) return;
    renameGroup(groupId, editName.trim());
    setEditingGroupId(null);
    setSuccessMessage('Group name updated successfully.');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handlePromptDelete = (groupId: string, groupName: string, count: number) => {
    setError('');
    setSuccessMessage('');
    setConfirmDeleteGroup({ id: groupId, name: groupName, count });
  };

  const executeDeleteGroup = async (groupId: string, groupName: string, countInGroup: number) => {
    setError('');
    setSuccessMessage('');

    try {
      setDeletingGroupId(groupId);
      await deleteGroup(groupId);
      const movedText = countInGroup > 0 ? ` ${countInGroup} customer(s) were automatically moved to the Default Group.` : '';
      setSuccessMessage(`Group "${groupName}" deleted successfully!${movedText}`);
      setConfirmDeleteGroup(null);
    } catch (err: any) {
      console.error('Delete group error:', err);
      setError(err?.message || `Failed to delete group "${groupName}". Please try again.`);
    } finally {
      setDeletingGroupId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-emerald-700" />
            <h3 className="font-extrabold text-slate-800 text-base">Manage Customer Groups</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto text-xs flex-1">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold flex items-start gap-2 animate-in fade-in duration-150">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-start gap-2 animate-in fade-in duration-150">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Add Group Form */}
          <form onSubmit={handleAddGroup} className="flex items-center space-x-2">
            <input
              type="text"
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              placeholder="e.g. Wholesale, Regular Credit, Area-1..."
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-semibold focus:outline-hidden focus:border-emerald-600 focus:bg-white"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs flex items-center space-x-1 shadow-2xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add</span>
            </button>
          </form>

          {/* Groups List */}
          <div className="space-y-2 pt-2">
            <label className="font-bold text-slate-700 uppercase text-[10px] tracking-wider">
              Existing Groups ({groups.filter((g) => !g.isDeleted).length})
            </label>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-slate-50/50">
              {groups
                .filter((g) => !g.isDeleted)
                .map((g) => {
                  const count = customers.filter(
                    (c) => !c.isDeleted && c.isActive && c.groupId === g.groupId
                  ).length;
                  const isDeletingThis = deletingGroupId === g.groupId;
                  const isConfirmingThis = confirmDeleteGroup?.id === g.groupId;

                  return (
                    <div key={g.groupId} className="bg-white">
                      <div className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                        {editingGroupId === g.groupId ? (
                          <div className="flex items-center space-x-2 flex-1 mr-2">
                            <input
                              type="text"
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className="flex-1 bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs font-bold"
                            />
                            <button
                              onClick={() => handleSaveRename(g.groupId)}
                              className="p-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <div>
                            <div className="font-bold text-slate-900 text-xs flex items-center gap-2">
                              {g.groupName}
                              {g.isSystem && (
                                <span className="bg-slate-100 text-slate-600 text-[9px] px-1.5 py-0.5 rounded font-bold">
                                  DEFAULT
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400">{count} customer(s)</div>
                          </div>
                        )}

                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => handleStartRename(g.groupId, g.groupName)}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors"
                            title="Rename Group"
                            disabled={deletingGroupId !== null}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {!g.isSystem && (
                            <button
                              onClick={() => handlePromptDelete(g.groupId, g.groupName, count)}
                              disabled={deletingGroupId !== null}
                              className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors disabled:opacity-50"
                              title="Delete Group"
                            >
                              {isDeletingThis ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-600" />
                              ) : (
                                <Trash2 className="w-3.5 h-3.5" />
                              )}
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Inline Confirmation Card */}
                      {isConfirmingThis && (
                        <div className="p-3 bg-rose-50/90 border-t border-rose-200 text-xs space-y-2 animate-in fade-in duration-150">
                          <div className="font-bold text-rose-900">
                            Delete "{g.groupName}"?
                          </div>
                          <p className="text-[11px] text-rose-700 leading-relaxed">
                            {count > 0
                              ? `Only this group will be deleted. ${count} customer(s) will be automatically moved to the Default Group.`
                              : 'Only this group will be removed. No customer accounts or data will be lost.'}
                          </p>
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => executeDeleteGroup(g.groupId, g.groupName, count)}
                              disabled={deletingGroupId !== null}
                              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
                            >
                              {isDeletingThis ? (
                                <>
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  <span>Deleting...</span>
                                </>
                              ) : (
                                <span>Confirm Delete</span>
                              )}
                            </button>
                            <button
                              onClick={() => setConfirmDeleteGroup(null)}
                              disabled={deletingGroupId !== null}
                              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold rounded-xl text-xs transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 text-white font-bold rounded-xl text-xs hover:bg-slate-900 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
