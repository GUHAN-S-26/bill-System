import React from 'react';
import { Home, Users, Plus, Receipt, BarChart3 } from 'lucide-react';

export type TabType = 'home' | 'customers' | 'billing' | 'reports';

interface BottomNavProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  onOpenFab: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab, onOpenFab }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30 px-4 py-2 shadow-lg">
      <div className="max-w-md mx-auto flex items-center justify-between relative">
        {/* Home Tab */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg transition-all ${
            activeTab === 'home' ? 'text-emerald-700 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-1">Home</span>
        </button>

        {/* Customers Tab */}
        <button
          onClick={() => setActiveTab('customers')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg transition-all ${
            activeTab === 'customers' ? 'text-emerald-700 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className={`w-5 h-5 ${activeTab === 'customers' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-1">Customers</span>
        </button>

        {/* Center Floating Action Button (FAB) */}
        <div className="relative -top-5 flex justify-center">
          <button
            onClick={onOpenFab}
            className="w-14 h-14 bg-emerald-700 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-emerald-800 active:scale-95 transition-transform border-4 border-white focus:outline-hidden"
            title="Quick Action"
          >
            <Plus className="w-8 h-8 stroke-[2.5]" />
          </button>
        </div>

        {/* Billing Tab */}
        <button
          onClick={() => setActiveTab('billing')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg transition-all ${
            activeTab === 'billing' ? 'text-emerald-700 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Receipt className={`w-5 h-5 ${activeTab === 'billing' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-1">Billing</span>
        </button>

        {/* Reports Tab */}
        <button
          onClick={() => setActiveTab('reports')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg transition-all ${
            activeTab === 'reports' ? 'text-emerald-700 font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart3 className={`w-5 h-5 ${activeTab === 'reports' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-1">Reports</span>
        </button>
      </div>
    </nav>
  );
};
