import React, { useState } from 'react';
import {
  RefreshCw,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  Wifi,
  WifiOff,
  Database,
  Globe,
  Save,
  ArrowLeft,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { exportFullShopBackupJSON, triggerGoogleSheetsSync } from '../../services/sheetsBackup';

interface BackupSyncViewProps {
  onBack: () => void;
}

export const BackupSyncView: React.FC<BackupSyncViewProps> = ({ onBack }) => {
  const {
    settings,
    updateSettings,
    customers,
    bills,
    payments,
    isOnline,
    toggleOnlineStatus,
    syncQueue,
    isSyncing,
    triggerSync,
  } = useApp();

  const [webhookUrl, setWebhookUrl] = useState(settings.googleSheetsWebhookUrl || '');
  const [syncResult, setSyncResult] = useState<string | null>(null);

  const handleSaveWebhook = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({ googleSheetsWebhookUrl: webhookUrl.trim() });
    setSyncResult('Google Sheets App Script URL updated successfully!');
  };

  const handleSheetsSyncNow = async () => {
    setSyncResult('Initiating Google Sheets mirror sync...');
    const payload = {
      shopName: settings.shopName,
      customersCount: customers.length,
      billsCount: bills.length,
      paymentsCount: payments.length,
      timestamp: new Date().toISOString(),
    };
    const res = await triggerGoogleSheetsSync(webhookUrl, payload);
    setSyncResult(res.message);
  };

  const handleFullBackup = () => {
    exportFullShopBackupJSON(settings, customers, bills, payments);
  };

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-slate-600 hover:text-slate-900 font-bold text-sm bg-white border border-slate-200 px-3 py-1.5 rounded-xl shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h1 className="text-lg font-black text-slate-900">Backup & Cloud Sync</h1>
        <div className="w-16"></div>
      </div>

      {/* Sync Status Box */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                isOnline ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
              }`}
            >
              {isOnline ? <Wifi className="w-6 h-6" /> : <WifiOff className="w-6 h-6" />}
            </div>
            <div>
              <h2 className="font-extrabold text-slate-900 text-base">
                Firestore Offline Engine: {isOnline ? 'ONLINE' : 'OFFLINE'}
              </h2>
              <p className="text-xs text-slate-500">
                {syncQueue.length === 0
                  ? 'All local transactions are synced with primary Cloud Firestore.'
                  : `${syncQueue.length} unsynced change(s) queued locally.`}
              </p>
            </div>
          </div>

          <button
            onClick={toggleOnlineStatus}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
              isOnline
                ? 'bg-amber-50 text-amber-800 border-amber-200'
                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
            }`}
          >
            Switch to {isOnline ? 'Offline' : 'Online'}
          </button>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Last Synced:{' '}
            <span className="font-bold text-slate-800">
              {settings.lastSyncedAt
                ? new Date(settings.lastSyncedAt).toLocaleString('en-IN')
                : 'Never'}
            </span>
          </div>

          <button
            onClick={triggerSync}
            disabled={isSyncing}
            className="flex items-center space-x-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Sync Firestore Now'}</span>
          </button>
        </div>
      </div>

      {/* Google Sheets Sync Mirror Settings */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">
              Google Sheets Secondary Backup Mirror
            </h3>
            <p className="text-xs text-slate-500">
              Synchronizes shop bills & payments directly to Google Sheets via Google Apps Script.
            </p>
          </div>
        </div>

        {syncResult && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{syncResult}</span>
          </div>
        )}

        <form onSubmit={handleSaveWebhook} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Google Apps Script Webhook URL
            </label>
            <input
              type="url"
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              placeholder="https://script.google.com/macros/s/.../exec"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-hidden focus:border-emerald-600"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              type="submit"
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition-colors flex items-center space-x-1"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Webhook</span>
            </button>

            <button
              type="button"
              onClick={handleSheetsSyncNow}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl transition-colors shadow-2xs flex items-center space-x-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Test & Mirror to Sheets</span>
            </button>
          </div>
        </form>
      </div>

      {/* Full Local JSON Backup Download */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs flex items-center justify-between">
        <div>
          <h3 className="font-extrabold text-slate-900 text-sm">Full Database JSON Export</h3>
          <p className="text-xs text-slate-500">
            Download local offline database backup file (customers, bills, payments, audit logs).
          </p>
        </div>

        <button
          onClick={handleFullBackup}
          className="flex items-center space-x-1.5 bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-2xs hover:bg-slate-800 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export Backup</span>
        </button>
      </div>
    </div>
  );
};
