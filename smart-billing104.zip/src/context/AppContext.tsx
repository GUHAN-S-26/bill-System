import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Customer,
  CustomerGroup,
  Bill,
  Payment,
  ShopSettings,
  User,
  AuditLog,
  SyncQueueItem,
  StatementItem,
} from '../types';
import {
  getStoredSettings,
  saveStoredSettings,
  getStoredUser,
  saveStoredUser,
  getStoredGroups,
  saveStoredGroups,
  getStoredCustomers,
  saveStoredCustomers,
  getStoredBills,
  saveStoredBills,
  getStoredPayments,
  saveStoredPayments,
  getStoredAuditLogs,
  saveStoredAuditLogs,
  getSyncQueue,
  pushToSyncQueue,
  clearSyncQueue,
  getOnlineStatus,
  saveOnlineStatus,
  recalculateCustomerTotals,
  resetToSeedData,
} from '../services/storage';
import {
  db,
  collections,
  seedFirestoreIfEmpty,
  saveSettingsToFirestore,
  saveGroupToFirestore,
  deleteGroupFromFirestore,
  saveCustomerToFirestore,
  saveBillToFirestore,
  savePaymentToFirestore,
  saveAuditLogToFirestore,
  saveActiveOwnerSessionToFirestore,
  clearActiveOwnerSessionInFirestore,
} from '../services/firebase';
import { onSnapshot } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { getTimestampMs, formatAuditDateTime } from '../utils/dateUtils';
import {
  auth,
  loginWithFirebase,
  changeOwnerPasswordInFirebase,
  logoutFirebase,
  resolveOwnerEmail,
} from '../services/authService';

interface AppContextType {
  user: User | null;
  login: (username: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => Promise<void>;
  changePassword: (currentPass: string, newPass: string) => Promise<{ success: boolean; message: string }>;
  isAuthenticated: boolean;

  settings: ShopSettings;
  updateSettings: (newSettings: Partial<ShopSettings>) => void;

  isOnline: boolean;
  toggleOnlineStatus: () => void;
  syncQueue: SyncQueueItem[];
  isSyncing: boolean;
  triggerSync: () => Promise<void>;

  groups: CustomerGroup[];
  addGroup: (groupName: string) => CustomerGroup;
  renameGroup: (groupId: string, newName: string) => void;
  deleteGroup: (groupId: string) => Promise<void>;

  customers: Customer[];
  addCustomer: (customerData: Omit<Customer, 'customerId' | 'currentBalance' | 'totalPurchase' | 'totalPaid' | 'createdAt' | 'updatedAt' | 'isActive' | 'isDeleted'>) => Customer;
  updateCustomer: (customerId: string, customerData: Partial<Customer>) => void;
  deleteCustomer: (customerId: string) => void;
  getCustomerById: (customerId: string) => Customer | undefined;
  getCustomerStatement: (customerId: string) => StatementItem[];

  bills: Bill[];
  addBill: (billData: Omit<Bill, 'billId' | 'billNumber' | 'createdAt' | 'updatedAt' | 'isDeleted'>) => Bill;
  updateBill: (billId: string, updatedData: Partial<Bill>) => void;
  deleteBill: (billId: string) => void;

  payments: Payment[];
  addPayment: (paymentData: Omit<Payment, 'paymentId' | 'createdAt' | 'updatedAt' | 'isDeleted'>) => Payment;
  updatePayment: (paymentId: string, updatedData: Partial<Payment>) => void;
  deletePayment: (paymentId: string) => void;

  auditLogs: AuditLog[];

  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => getStoredUser());
  const [settings, setSettings] = useState<ShopSettings>(() => getStoredSettings());
  const [groups, setGroups] = useState<CustomerGroup[]>(() => getStoredGroups());
  const [customers, setCustomers] = useState<Customer[]>(() => getStoredCustomers());
  const [bills, setBills] = useState<Bill[]>(() => getStoredBills());
  const [payments, setPayments] = useState<Payment[]>(() => getStoredPayments());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => getStoredAuditLogs());
  const [syncQueue, setSyncQueue] = useState<SyncQueueItem[]>(() => getSyncQueue());
  const [isOnline, setIsOnline] = useState<boolean>(() => getOnlineStatus());
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Initial Firebase Seeding & Realtime Firestore Listeners
  useEffect(() => {
    seedFirestoreIfEmpty();

    // Listen to Settings
    const unsubSettings = onSnapshot(collections.settings, (snapshot) => {
      if (!snapshot.empty) {
        const docData = snapshot.docs[0].data() as ShopSettings;
        setSettings(docData);
        saveStoredSettings(docData);
        if (docData.ownerName) {
          setUser((prev) => (prev ? { ...prev, name: docData.ownerName } : prev));
        }
      }
    });

    // Listen to Customer Groups
    const unsubGroups = onSnapshot(collections.groups, (snapshot) => {
      if (!snapshot.empty) {
        const list = snapshot.docs.map((doc) => doc.data() as CustomerGroup);
        setGroups(list);
        saveStoredGroups(list);
      }
    });

    // Listen to Customers
    const unsubCustomers = onSnapshot(collections.customers, (snapshot) => {
      if (!snapshot.empty) {
        const list = snapshot.docs.map((doc) => doc.data() as Customer);
        setCustomers(list);
        saveStoredCustomers(list);
      }
    });

    // Listen to Bills
    const unsubBills = onSnapshot(collections.bills, (snapshot) => {
      if (!snapshot.empty) {
        const list = snapshot.docs.map((doc) => doc.data() as Bill);
        // Sort descending by date (newest first)
        list.sort((a, b) => getTimestampMs(b.createdAt) - getTimestampMs(a.createdAt));
        setBills(list);
        saveStoredBills(list);
      }
    });

    // Listen to Payments
    const unsubPayments = onSnapshot(collections.payments, (snapshot) => {
      if (!snapshot.empty) {
        const list = snapshot.docs.map((doc) => doc.data() as Payment);
        list.sort((a, b) => getTimestampMs(b.createdAt) - getTimestampMs(a.createdAt));
        setPayments(list);
        saveStoredPayments(list);
      }
    });

    // Listen to Audit Logs
    const unsubLogs = onSnapshot(collections.auditLogs, (snapshot) => {
      if (!snapshot.empty) {
        const list = snapshot.docs.map((doc) => doc.data() as AuditLog);
        list.sort((a, b) => getTimestampMs(b.performedAt) - getTimestampMs(a.performedAt));
        setAuditLogs(list);
        saveStoredAuditLogs(list);
      }
    });

    return () => {
      unsubSettings();
      unsubGroups();
      unsubCustomers();
      unsubBills();
      unsubPayments();
      unsubLogs();
    };
  }, []);

  // Sync state changes to local storage as cache
  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  useEffect(() => {
    if (user) saveStoredUser(user);
  }, [user]);

  useEffect(() => {
    saveStoredGroups(groups);
  }, [groups]);

  useEffect(() => {
    saveStoredCustomers(customers);
  }, [customers]);

  useEffect(() => {
    saveStoredBills(bills);
  }, [bills]);

  useEffect(() => {
    saveStoredPayments(payments);
  }, [payments]);

  useEffect(() => {
    saveStoredAuditLogs(auditLogs);
  }, [auditLogs]);

  // Subscribe to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        // Sync active user state if signed in via Firebase Auth
        const email = firebaseUser.email || '';
        const { owner } = resolveOwnerEmail(email);
        const displayName = owner?.displayName || firebaseUser.displayName || email.split('@')[0];
        const activeUser: User = {
          userId: `USR-${(owner?.username || email.split('@')[0]).toUpperCase()}`,
          authUid: firebaseUser.uid,
          name: displayName,
          username: owner?.username || email.split('@')[0],
          role: 'owner',
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        setUser(activeUser);
        saveStoredUser(activeUser);
        setSettings((prev) => ({ ...prev, ownerName: displayName }));

        // Update active owner session in Firebase
        saveActiveOwnerSessionToFirestore({
          ownerId: activeUser.username,
          name: activeUser.name,
          email: `${activeUser.username}@shankarshop.com`,
          role: 'Owner',
          loginTime: activeUser.createdAt,
          lastActiveTime: new Date().toISOString(),
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Auth functions connected to Firebase Authentication
  const login = async (
    username: string,
    pass: string
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      const { firebaseUser, ownerProfile } = await loginWithFirebase(username, pass);
      const loggedUser: User = {
        userId: `USR-${ownerProfile.username.toUpperCase()}`,
        authUid: firebaseUser.uid || `AUTH-${ownerProfile.username.toUpperCase()}`,
        name: ownerProfile.displayName,
        username: ownerProfile.username,
        role: ownerProfile.role,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setUser(loggedUser);
      saveStoredUser(loggedUser);
      setSettings((prev) => {
        const next = { ...prev, ownerName: ownerProfile.displayName };
        saveStoredSettings(next);
        return next;
      });

      // Save active session details to Firebase
      await saveActiveOwnerSessionToFirestore({
        ownerId: ownerProfile.username,
        name: ownerProfile.displayName,
        email: ownerProfile.email,
        role: 'Owner',
        loginTime: new Date().toISOString(),
        lastActiveTime: new Date().toISOString(),
      });

      logAudit('Authentication', 'Login', loggedUser.userId, { email: ownerProfile.email });
      return { success: true };
    } catch (err: any) {
      console.error('Firebase Auth login error:', err);
      return {
        success: false,
        message: err?.message || 'Invalid username or password.',
      };
    }
  };

  const logout = async (): Promise<void> => {
    if (user?.username) {
      logAudit('Authentication', 'Logout', user.userId, { email: `${user.username}@shankarshop.com` });
      await clearActiveOwnerSessionInFirestore(user.username);
    }
    await logoutFirebase();
    setUser(null);
    localStorage.removeItem('smart_billing_user_v1');
  };

  const changePassword = async (
    currentPass: string,
    newPass: string
  ): Promise<{ success: boolean; message: string }> => {
    const username = user?.username || 'venkatesh';
    const result = await changeOwnerPasswordInFirebase(username, currentPass, newPass);
    if (result.success && user) {
      logAudit('Authentication', 'Updated Password', user.userId, {
        username: user.username,
      });
    }
    return result;
  };

  const updateSettings = (newSettings: Partial<ShopSettings>) => {
    const updated = {
      ...settings,
      ...newSettings,
      updatedAt: new Date().toISOString(),
    };
    setSettings(updated);
    saveStoredSettings(updated);
    saveSettingsToFirestore(updated);

    if (newSettings.ownerName) {
      setUser((prev) => {
        if (!prev) return prev;
        const updatedUser = { ...prev, name: newSettings.ownerName!, updatedAt: new Date().toISOString() };
        saveStoredUser(updatedUser);
        return updatedUser;
      });
    }

    logAudit('Shop Settings', 'Updated Shop Settings', 'main', newSettings);
  };

  const toggleOnlineStatus = () => {
    const next = !isOnline;
    setIsOnline(next);
    saveOnlineStatus(next);
  };

  const triggerSync = async () => {
    setIsSyncing(true);
    // Push local state snapshots to Firebase Firestore
    await saveSettingsToFirestore(settings);
    for (const g of groups) await saveGroupToFirestore(g);
    for (const c of customers) await saveCustomerToFirestore(c);
    for (const b of bills) await saveBillToFirestore(b);
    for (const p of payments) await savePaymentToFirestore(p);
    for (const l of auditLogs) await saveAuditLogToFirestore(l);

    clearSyncQueue();
    setSyncQueue([]);
    const now = new Date().toISOString();
    const updated = { ...settings, lastSyncedAt: now };
    setSettings(updated);
    await saveSettingsToFirestore(updated);
    setIsSyncing(false);
  };

  const logAudit = (
    module: AuditLog['module'],
    action: string,
    recordId: string,
    details?: any
  ) => {
    const currentUsername = user?.username || 'venkatesh';
    const currentName = user?.name || settings.ownerName || 'Venkatesh';
    const ownerEmail = currentUsername.includes('@')
      ? currentUsername
      : `${currentUsername}@shankarshop.com`;

    const now = new Date();
    const log: AuditLog = {
      logId: 'LOG-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      ownerName: currentName,
      ownerEmail: ownerEmail,
      action: action,
      module: module,
      recordId: recordId || 'N/A',
      dateTime: formatAuditDateTime(now),
      performedBy: currentName,
      performedAt: now.toISOString(),
      details: details || null,
    };

    setAuditLogs((prev) => [log, ...prev]);
    saveAuditLogToFirestore(log);
    pushToSyncQueue(`${action}_${module}`, { recordId, details });
    setSyncQueue(getSyncQueue());
  };

  // Group functions
  const addGroup = (groupName: string): CustomerGroup => {
    const newGroup: CustomerGroup = {
      groupId: 'GRP-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      groupName: groupName.trim(),
      customerCount: 0,
      isSystem: false,
      isActive: true,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setGroups((prev) => [...prev, newGroup]);
    saveGroupToFirestore(newGroup);
    logAudit('Groups', 'Created Group', newGroup.groupId, newGroup);
    return newGroup;
  };

  const renameGroup = (groupId: string, newName: string) => {
    const updatedGroups = groups.map((g) =>
      g.groupId === groupId ? { ...g, groupName: newName, updatedAt: new Date().toISOString() } : g
    );
    setGroups(updatedGroups);

    const targetGroup = updatedGroups.find((g) => g.groupId === groupId);
    if (targetGroup) saveGroupToFirestore(targetGroup);

    // Update group name in customers too
    const updatedCustomers = customers.map((c) =>
      c.groupId === groupId ? { ...c, groupName: newName } : c
    );
    setCustomers(updatedCustomers);
    updatedCustomers.filter((c) => c.groupId === groupId).forEach((c) => saveCustomerToFirestore(c));

    logAudit('Groups', 'Updated Group', groupId, { newName });
  };

  const deleteGroup = async (groupId: string): Promise<void> => {
    const defaultGroup = groups.find((g) => g.isSystem) || groups.find((g) => g.groupId !== groupId) || groups[0];
    if (!defaultGroup || groupId === defaultGroup.groupId) {
      throw new Error('Cannot delete the default system group.');
    }

    const customersToMove = customers.filter((c) => c.groupId === groupId);

    const updatedCustomers = customers.map((c) =>
      c.groupId === groupId
        ? {
            ...c,
            groupId: defaultGroup.groupId,
            groupName: defaultGroup.groupName,
            updatedAt: new Date().toISOString(),
          }
        : c
    );

    setCustomers(updatedCustomers);
    saveStoredCustomers(updatedCustomers);

    const updatedGroups = groups.filter((g) => g.groupId !== groupId);
    setGroups(updatedGroups);
    saveStoredGroups(updatedGroups);

    const customerPromises = customersToMove.map((c) => {
      const updatedCustomer = {
        ...c,
        groupId: defaultGroup.groupId,
        groupName: defaultGroup.groupName,
        updatedAt: new Date().toISOString(),
      };
      return saveCustomerToFirestore(updatedCustomer);
    });

    await Promise.all(customerPromises);
    await deleteGroupFromFirestore(groupId);

    logAudit('Groups', 'Deleted Group', groupId, {
      movedCustomersCount: customersToMove.length,
      targetGroupId: defaultGroup.groupId,
    });
  };

  // Helper to re-evaluate single customer totals
  const recalculateSingleCustomer = (
    c: Customer,
    currentBills: Bill[],
    currentPayments: Payment[]
  ) => {
    return recalculateCustomerTotals(c, currentBills, currentPayments);
  };

  // Customer functions
  const addCustomer = (customerData: Omit<Customer, 'customerId' | 'currentBalance' | 'totalPurchase' | 'totalPaid' | 'createdAt' | 'updatedAt' | 'isActive' | 'isDeleted'>): Customer => {
    const customerId = 'CUS-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    const newCustomerRaw: Customer = {
      ...customerData,
      customerId,
      currentBalance: customerData.openingBalance || 0,
      totalPurchase: 0,
      totalPaid: 0,
      isActive: true,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: user?.name || 'Owner',
    };

    setCustomers((prev) => [...prev, newCustomerRaw]);
    saveCustomerToFirestore(newCustomerRaw);

    // Update group customer count
    setGroups((prev) => {
      const updated = prev.map((g) =>
        g.groupId === customerData.groupId
          ? { ...g, customerCount: g.customerCount + 1 }
          : g
      );
      const grp = updated.find((g) => g.groupId === customerData.groupId);
      if (grp) saveGroupToFirestore(grp);
      return updated;
    });

    logAudit('Customers', 'Created Customer', customerId, { name: newCustomerRaw.customerName });
    return newCustomerRaw;
  };

  const updateCustomer = (customerId: string, customerData: Partial<Customer>) => {
    let updatedCustomer: Customer | undefined;
    const updatedCustomers = customers.map((c) => {
      if (c.customerId === customerId) {
        const merged = { ...c, ...customerData, updatedAt: new Date().toISOString() };
        updatedCustomer = recalculateSingleCustomer(merged, bills, payments);
        return updatedCustomer;
      }
      return c;
    });

    setCustomers(updatedCustomers);
    saveStoredCustomers(updatedCustomers);
    if (updatedCustomer) saveCustomerToFirestore(updatedCustomer);
    logAudit('Customers', 'Updated Customer', customerId, customerData);
  };

  const deleteCustomer = (customerId: string) => {
    let deletedCust: Customer | undefined;
    const updatedCustomers = customers.map((c) => {
      if (c.customerId === customerId) {
        deletedCust = { ...c, isDeleted: true, updatedAt: new Date().toISOString() };
        return deletedCust;
      }
      return c;
    });

    setCustomers(updatedCustomers);
    saveStoredCustomers(updatedCustomers);
    if (deletedCust) saveCustomerToFirestore(deletedCust);
    logAudit('Customers', 'Deleted Customer', customerId);
  };

  const getCustomerById = (customerId: string) => {
    return customers.find((c) => c.customerId === customerId);
  };

  const getCustomerStatement = (customerId: string): StatementItem[] => {
    const customer = customers.find((c) => c.customerId === customerId);
    if (!customer) return [];

    const activeBills = bills
      .filter((b) => b.customerId === customerId && !b.isDeleted)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    const activePayments = payments
      .filter((p) => p.customerId === customerId && !p.isDeleted)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    const items: StatementItem[] = [];

    // Opening Balance Item
    if (customer.openingBalance !== 0) {
      items.push({
        id: 'OB-' + customerId,
        type: 'opening_balance',
        date: customer.createdAt,
        refNumber: 'OPEN-BAL',
        description: 'Opening Credit Balance',
        debit: customer.openingBalance > 0 ? customer.openingBalance : 0,
        credit: customer.openingBalance < 0 ? Math.abs(customer.openingBalance) : 0,
        runningBalance: customer.openingBalance,
      });
    }

    // Merge Bills & Payments in chronological order
    const mergedList: ({ kind: 'bill'; data: Bill } | { kind: 'payment'; data: Payment })[] = [
      ...activeBills.map((b) => ({ kind: 'bill' as const, data: b })),
      ...activePayments.map((p) => ({ kind: 'payment' as const, data: p })),
    ].sort(
      (a, b) => getTimestampMs(a.data.createdAt) - getTimestampMs(b.data.createdAt)
    );

    let runningBal = customer.openingBalance || 0;

    mergedList.forEach((item) => {
      if (item.kind === 'bill') {
        const b = item.data;
        runningBal += b.subtotal;
        items.push({
          id: b.billId,
          type: 'bill',
          date: b.createdAt,
          refNumber: b.billNumber,
          description: `Bill (#${b.billNumber}) - ${b.entries.length} items`,
          debit: b.subtotal,
          credit: 0,
          runningBalance: runningBal,
          rawItem: b,
        });

        if (b.paidAmount > 0) {
          runningBal -= b.paidAmount;
          items.push({
            id: 'BP-' + b.billId,
            type: 'payment',
            date: b.createdAt,
            refNumber: `PAY-${b.billNumber}`,
            description: `Paid at Billing (${b.paymentMethod.toUpperCase()})`,
            debit: 0,
            credit: b.paidAmount,
            runningBalance: runningBal,
            rawItem: b,
          });
        }
      } else {
        const p = item.data;
        runningBal -= p.amount;
        items.push({
          id: p.paymentId,
          type: 'payment',
          date: p.createdAt,
          refNumber: p.paymentId,
          description: `Payment Received (${p.paymentMethod.toUpperCase()}) ${p.remarks ? '- ' + p.remarks : ''}`,
          debit: 0,
          credit: p.amount,
          runningBalance: runningBal,
          rawItem: p,
        });
      }
    });

    return items;
  };

  // Bill functions
  const addBill = (billData: Omit<Bill, 'billId' | 'billNumber' | 'createdAt' | 'updatedAt' | 'isDeleted'>): Bill => {
    const billId = 'BIL-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    const invSeq = Math.floor(1000 + Math.random() * 9000);
    const billNumber = `INV-${new Date().getFullYear()}-${invSeq}`;

    const newBill: Bill = {
      ...billData,
      billId,
      billNumber,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: user?.name || 'Owner',
    };

    const newBills = [newBill, ...bills];
    setBills(newBills);
    saveStoredBills(newBills);
    saveBillToFirestore(newBill);

    // Recalculate customer totals
    const updatedCustomers = customers.map((c) => {
      if (c.customerId === billData.customerId) {
        const updatedCust = recalculateCustomerTotals(c, newBills, payments);
        saveCustomerToFirestore(updatedCust);
        return updatedCust;
      }
      return c;
    });
    setCustomers(updatedCustomers);
    saveStoredCustomers(updatedCustomers);

    logAudit('Billing', 'Created Bill', billId, { amount: newBill.subtotal, customer: newBill.customerName });
    return newBill;
  };

  const updateBill = (billId: string, updatedData: Partial<Bill>) => {
    let affectedCustomerId = '';
    let updatedBill: Bill | undefined;

    const updatedBills = bills.map((b) => {
      if (b.billId === billId) {
        affectedCustomerId = b.customerId;
        updatedBill = { ...b, ...updatedData, updatedAt: new Date().toISOString() };
        return updatedBill;
      }
      return b;
    });

    setBills(updatedBills);
    saveStoredBills(updatedBills);
    if (updatedBill) saveBillToFirestore(updatedBill);

    if (affectedCustomerId) {
      const updatedCustomers = customers.map((c) => {
        if (c.customerId === affectedCustomerId) {
          const updatedCust = recalculateCustomerTotals(c, updatedBills, payments);
          saveCustomerToFirestore(updatedCust);
          return updatedCust;
        }
        return c;
      });
      setCustomers(updatedCustomers);
      saveStoredCustomers(updatedCustomers);
    }

    logAudit('Billing', 'Updated Bill', billId, updatedData);
  };

  const deleteBill = (billId: string) => {
    let affectedCustomerId = '';
    let deletedBill: Bill | undefined;

    const updatedBills = bills.map((b) => {
      if (b.billId === billId) {
        affectedCustomerId = b.customerId;
        deletedBill = { ...b, isDeleted: true, updatedAt: new Date().toISOString() };
        return deletedBill;
      }
      return b;
    });

    setBills(updatedBills);
    saveStoredBills(updatedBills);
    if (deletedBill) saveBillToFirestore(deletedBill);

    if (affectedCustomerId) {
      const updatedCustomers = customers.map((c) => {
        if (c.customerId === affectedCustomerId) {
          const updatedCust = recalculateCustomerTotals(c, updatedBills, payments);
          saveCustomerToFirestore(updatedCust);
          return updatedCust;
        }
        return c;
      });
      setCustomers(updatedCustomers);
      saveStoredCustomers(updatedCustomers);
    }

    logAudit('Billing', 'Deleted Bill', billId);
  };

  // Payment functions
  const addPayment = (paymentData: Omit<Payment, 'paymentId' | 'createdAt' | 'updatedAt' | 'isDeleted'>): Payment => {
    const paymentId = 'PAY-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    const newPayment: Payment = {
      ...paymentData,
      paymentId,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      receivedBy: user?.name || 'Owner',
    };

    const newPayments = [newPayment, ...payments];
    setPayments(newPayments);
    saveStoredPayments(newPayments);
    savePaymentToFirestore(newPayment);

    // Recalculate customer totals
    const updatedCustomers = customers.map((c) => {
      if (c.customerId === paymentData.customerId) {
        const updatedCust = recalculateCustomerTotals(c, bills, newPayments);
        saveCustomerToFirestore(updatedCust);
        return updatedCust;
      }
      return c;
    });
    setCustomers(updatedCustomers);
    saveStoredCustomers(updatedCustomers);

    logAudit('Payments', 'Received Payment', paymentId, { amount: newPayment.amount, customer: newPayment.customerName });
    return newPayment;
  };

  const updatePayment = (paymentId: string, updatedData: Partial<Payment>) => {
    let affectedCustomerId = '';
    let updatedPay: Payment | undefined;

    const updatedPayments = payments.map((p) => {
      if (p.paymentId === paymentId) {
        affectedCustomerId = p.customerId;
        updatedPay = { ...p, ...updatedData, updatedAt: new Date().toISOString() };
        return updatedPay;
      }
      return p;
    });

    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);
    if (updatedPay) savePaymentToFirestore(updatedPay);

    if (affectedCustomerId) {
      const updatedCustomers = customers.map((c) => {
        if (c.customerId === affectedCustomerId) {
          const updatedCust = recalculateCustomerTotals(c, bills, updatedPayments);
          saveCustomerToFirestore(updatedCust);
          return updatedCust;
        }
        return c;
      });
      setCustomers(updatedCustomers);
      saveStoredCustomers(updatedCustomers);
    }

    logAudit('Payments', 'Updated Payment', paymentId, updatedData);
  };

  const deletePayment = (paymentId: string) => {
    let affectedCustomerId = '';
    let deletedPay: Payment | undefined;

    const updatedPayments = payments.map((p) => {
      if (p.paymentId === paymentId) {
        affectedCustomerId = p.customerId;
        deletedPay = { ...p, isDeleted: true, updatedAt: new Date().toISOString() };
        return deletedPay;
      }
      return p;
    });

    setPayments(updatedPayments);
    saveStoredPayments(updatedPayments);
    if (deletedPay) savePaymentToFirestore(deletedPay);

    if (affectedCustomerId) {
      const updatedCustomers = customers.map((c) => {
        if (c.customerId === affectedCustomerId) {
          const updatedCust = recalculateCustomerTotals(c, bills, updatedPayments);
          saveCustomerToFirestore(updatedCust);
          return updatedCust;
        }
        return c;
      });
      setCustomers(updatedCustomers);
      saveStoredCustomers(updatedCustomers);
    }

    logAudit('Payments', 'Deleted Payment', paymentId);
  };

  const resetAllData = () => {
    resetToSeedData();
    setUser(getStoredUser());
    setSettings(getStoredSettings());
    setGroups(getStoredGroups());
    setCustomers(getStoredCustomers());
    setBills(getStoredBills());
    setPayments(getStoredPayments());
    setAuditLogs(getStoredAuditLogs());
    setSyncQueue([]);
    setIsOnline(true);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        login,
        logout,
        changePassword,
        isAuthenticated: !!user,
        settings,
        updateSettings,
        isOnline,
        toggleOnlineStatus,
        syncQueue,
        isSyncing,
        triggerSync,
        groups,
        addGroup,
        renameGroup,
        deleteGroup,
        customers,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        getCustomerById,
        getCustomerStatement,
        bills,
        addBill,
        updateBill,
        deleteBill,
        payments,
        addPayment,
        updatePayment,
        deletePayment,
        auditLogs,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return ctx;
};
