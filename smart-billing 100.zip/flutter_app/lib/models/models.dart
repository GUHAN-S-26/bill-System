class OwnerProfile {
  final String username;
  final String email;
  final String displayName;
  final String role;

  const OwnerProfile({
    required this.username,
    required this.email,
    required this.displayName,
    required this.role,
  });

  factory OwnerProfile.fromJson(Map<String, dynamic> json) {
    return OwnerProfile(
      username: json['username'] ?? '',
      email: json['email'] ?? '',
      displayName: json['displayName'] ?? '',
      role: json['role'] ?? 'owner',
    );
  }

  Map<String, dynamic> toJson() => {
        'username': username,
        'email': email,
        'displayName': displayName,
        'role': role,
      };
}

class Customer {
  final String customerId;
  final String customerName;
  final String phone;
  final String address;
  final String groupId;
  final double openingBalance;
  final double currentBalance;
  final String status; // active, deleted
  final String createdAt;
  final String updatedAt;

  Customer({
    required this.customerId,
    required this.customerName,
    required this.phone,
    required this.address,
    required this.groupId,
    required this.openingBalance,
    required this.currentBalance,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      customerId: json['customerId'] ?? '',
      customerName: json['customerName'] ?? '',
      phone: json['phone'] ?? '',
      address: json['address'] ?? '',
      groupId: json['groupId'] ?? 'grp-general',
      openingBalance: (json['openingBalance'] ?? 0).toDouble(),
      currentBalance: (json['currentBalance'] ?? 0).toDouble(),
      status: json['status'] ?? 'active',
      createdAt: json['createdAt'] ?? DateTime.now().toIso8601String(),
      updatedAt: json['updatedAt'] ?? DateTime.now().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() => {
        'customerId': customerId,
        'customerName': customerName,
        'phone': phone,
        'address': address,
        'groupId': groupId,
        'openingBalance': openingBalance,
        'currentBalance': currentBalance,
        'status': status,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
      };
}

class BillItem {
  final String id;
  final String name;
  final double quantity;
  final double rate;
  final double total;

  BillItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.rate,
    required this.total,
  });

  factory BillItem.fromJson(Map<String, dynamic> json) {
    return BillItem(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      quantity: (json['quantity'] ?? 1).toDouble(),
      rate: (json['rate'] ?? 0).toDouble(),
      total: (json['total'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'quantity': quantity,
        'rate': rate,
        'total': total,
      };
}

class Bill {
  final String billId;
  final String billNumber;
  final String customerId;
  final String customerName;
  final List<BillItem> items;
  final double subtotal;
  final double paidAmount;
  final double balance;
  final String paymentStatus; // Paid, Partial, Pending
  final String billDate;
  final String notes;

  Bill({
    required this.billId,
    required this.billNumber,
    required this.customerId,
    required this.customerName,
    required this.items,
    required this.subtotal,
    required this.paidAmount,
    required this.balance,
    required this.paymentStatus,
    required this.billDate,
    required this.notes,
  });

  factory Bill.fromJson(Map<String, dynamic> json) {
    var rawItems = json['items'] as List? ?? [];
    List<BillItem> parsedItems =
        rawItems.map((i) => BillItem.fromJson(Map<String, dynamic>.from(i))).toList();

    return Bill(
      billId: json['billId'] ?? '',
      billNumber: json['billNumber'] ?? '',
      customerId: json['customerId'] ?? '',
      customerName: json['customerName'] ?? '',
      items: parsedItems,
      subtotal: (json['subtotal'] ?? 0).toDouble(),
      paidAmount: (json['paidAmount'] ?? 0).toDouble(),
      balance: (json['balance'] ?? 0).toDouble(),
      paymentStatus: json['paymentStatus'] ?? 'Pending',
      billDate: json['billDate'] ?? DateTime.now().toIso8601String(),
      notes: json['notes'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'billId': billId,
        'billNumber': billNumber,
        'customerId': customerId,
        'customerName': customerName,
        'items': items.map((i) => i.toJson()).toList(),
        'subtotal': subtotal,
        'paidAmount': paidAmount,
        'balance': balance,
        'paymentStatus': paymentStatus,
        'billDate': billDate,
        'notes': notes,
      };
}

class Payment {
  final String paymentId;
  final String customerId;
  final String customerName;
  final double amount;
  final String paymentMethod; // Cash, UPI, Bank Transfer
  final String paymentDate;
  final String notes;

  Payment({
    required this.paymentId,
    required this.customerId,
    required this.customerName,
    required this.amount,
    required this.paymentMethod,
    required this.paymentDate,
    required this.notes,
  });

  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      paymentId: json['paymentId'] ?? '',
      customerId: json['customerId'] ?? '',
      customerName: json['customerName'] ?? '',
      amount: (json['amount'] ?? 0).toDouble(),
      paymentMethod: json['paymentMethod'] ?? 'Cash',
      paymentDate: json['paymentDate'] ?? DateTime.now().toIso8601String(),
      notes: json['notes'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'paymentId': paymentId,
        'customerId': customerId,
        'customerName': customerName,
        'amount': amount,
        'paymentMethod': paymentMethod,
        'paymentDate': paymentDate,
        'notes': notes,
      };
}

class ShopSettings {
  final String shopName;
  final String ownerName;
  final String phone;
  final String address;
  final String upiId;

  ShopSettings({
    required this.shopName,
    required this.ownerName,
    required this.phone,
    required this.address,
    required this.upiId,
  });

  factory ShopSettings.fromJson(Map<String, dynamic> json) {
    return ShopSettings(
      shopName: json['shopName'] ?? 'Shankar Shop',
      ownerName: json['ownerName'] ?? 'Venkatesh',
      phone: json['phone'] ?? '+91 98765 43210',
      address: json['address'] ?? 'Main Street, Market Road',
      upiId: json['upiId'] ?? 'shankarshop@upi',
    );
  }

  Map<String, dynamic> toJson() => {
        'shopName': shopName,
        'ownerName': ownerName,
        'phone': phone,
        'address': address,
        'upiId': upiId,
      };
}

class AuditLog {
  final String logId;
  final String ownerName;
  final String ownerEmail;
  final String action;
  final String module;
  final String recordId;
  final String dateTime;
  final String performedBy;
  final String performedAt;

  AuditLog({
    required this.logId,
    required this.ownerName,
    required this.ownerEmail,
    required this.action,
    required this.module,
    required this.recordId,
    required this.dateTime,
    required this.performedBy,
    required this.performedAt,
  });

  factory AuditLog.fromJson(Map<String, dynamic> json) {
    return AuditLog(
      logId: json['logId'] ?? '',
      ownerName: json['ownerName'] ?? '',
      ownerEmail: json['ownerEmail'] ?? '',
      action: json['action'] ?? '',
      module: json['module'] ?? 'System',
      recordId: json['recordId'] ?? 'N/A',
      dateTime: json['dateTime'] ?? '',
      performedBy: json['performedBy'] ?? '',
      performedAt: json['performedAt'] ?? DateTime.now().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() => {
        'logId': logId,
        'ownerName': ownerName,
        'ownerEmail': ownerEmail,
        'action': action,
        'module': module,
        'recordId': recordId,
        'dateTime': dateTime,
        'performedBy': performedBy,
        'performedAt': performedAt,
      };
}
