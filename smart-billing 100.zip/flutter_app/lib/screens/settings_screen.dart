import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../models/models.dart';
import 'audit_logs_screen.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late TextEditingController _shopNameController;
  late TextEditingController _ownerNameController;
  late TextEditingController _phoneController;
  late TextEditingController _addressController;
  late TextEditingController _upiController;

  @override
  void initState() {
    super.initState();
    _shopNameController = TextEditingController();
    _ownerNameController = TextEditingController();
    _phoneController = TextEditingController();
    _addressController = TextEditingController();
    _upiController = TextEditingController();
  }

  @override
  void dispose() {
    _shopNameController.dispose();
    _ownerNameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _upiController.dispose();
    super.dispose();
  }

  void _saveSettings(ShopSettings current) async {
    final updated = ShopSettings(
      shopName: _shopNameController.text.trim(),
      ownerName: _ownerNameController.text.trim(),
      phone: _phoneController.text.trim(),
      address: _addressController.text.trim(),
      upiId: _upiController.text.trim(),
    );

    await ref.read(firestoreServiceProvider).saveSettings(updated);
    ref.read(appNotifierProvider.notifier).logAudit(
          'Shop Settings',
          'Updated Shop Settings',
          'shop',
        );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Shop settings updated successfully!')),
      );
    }
  }

  void _logout() async {
    final owner = ref.read(currentOwnerProvider);
    if (owner != null) {
      ref.read(appNotifierProvider.notifier).logAudit(
            'Authentication',
            'Logout',
            'USR-${owner.username.toUpperCase()}',
          );
      await ref.read(firestoreServiceProvider).clearActiveSession(owner.username);
    }

    await ref.read(authServiceProvider).logout();
    ref.read(currentOwnerProvider.notifier).state = null;
  }

  @override
  Widget build(BuildContext context) {
    final settingsAsync = ref.watch(shopSettingsProvider);
    final owner = ref.watch(currentOwnerProvider);

    return Scaffold(
      body: settingsAsync.when(
        data: (settings) {
          if (_shopNameController.text.isEmpty) {
            _shopNameController.text = settings.shopName;
            _ownerNameController.text = owner?.displayName ?? settings.ownerName;
            _phoneController.text = settings.phone;
            _addressController.text = settings.address;
            _upiController.text = settings.upiId;
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Shop Profile & Configuration',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 16),

                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFF1F5F9)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextField(
                        controller: _shopNameController,
                        decoration:
                            const InputDecoration(labelText: 'Shop Name'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _ownerNameController,
                        decoration: const InputDecoration(
                            labelText: 'Owner Display Name'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _phoneController,
                        decoration:
                            const InputDecoration(labelText: 'Contact Phone'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _addressController,
                        decoration:
                            const InputDecoration(labelText: 'Shop Address'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _upiController,
                        decoration:
                            const InputDecoration(labelText: 'UPI QR / ID'),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _saveSettings(settings),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF15803D),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text('Save Shop Settings'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Audit Logs Button
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  child: ListTile(
                    leading: const Icon(Icons.shield_outlined,
                        color: Color(0xFF7C3AED)),
                    title: const Text('Audit Trail & Security Logs',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: const Text('View action history across all owners'),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded,
                        size: 16),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const AuditLogsScreen()),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),

                // Logout Button
                OutlinedButton.icon(
                  onPressed: _logout,
                  icon: const Icon(Icons.logout_rounded, color: Colors.red),
                  label: const Text('Logout Session',
                      style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.red),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Error: $err')),
      ),
    );
  }
}
