import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../models/models.dart';

class BillingScreen extends ConsumerStatefulWidget {
  const BillingScreen({super.key});

  @override
  ConsumerState<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends ConsumerState<BillingScreen> {
  Customer? _selectedCustomer;
  final List<BillItem> _items = [
    BillItem(id: '1', name: 'General Goods', quantity: 1, rate: 0, total: 0)
  ];
  final _amountController = TextEditingController();

  void _createBill() async {
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a customer first')),
      );
      return;
    }

    final amount = double.tryParse(_amountController.text) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid bill amount')),
      );
      return;
    }

    final billId = 'BIL-${DateTime.now().millisecondsSinceEpoch}';
    final billNumber = '${DateTime.now().millisecondsSinceEpoch}'.substring(6);

    final bill = Bill(
      billId: billId,
      billNumber: billNumber,
      customerId: _selectedCustomer!.customerId,
      customerName: _selectedCustomer!.customerName,
      items: [
        BillItem(
          id: '1',
          name: 'Grocery / Retail Items',
          quantity: 1,
          rate: amount,
          total: amount,
        )
      ],
      subtotal: amount,
      paidAmount: 0,
      balance: amount,
      paymentStatus: 'Pending',
      billDate: DateTime.now().toIso8601String(),
      notes: 'Quick Bill',
    );

    // Save Bill
    await ref.read(firestoreServiceProvider).saveBill(bill);

    // Update Customer Balance
    final updatedCustomer = Customer(
      customerId: _selectedCustomer!.customerId,
      customerName: _selectedCustomer!.customerName,
      phone: _selectedCustomer!.phone,
      address: _selectedCustomer!.address,
      groupId: _selectedCustomer!.groupId,
      openingBalance: _selectedCustomer!.openingBalance,
      currentBalance: _selectedCustomer!.currentBalance + amount,
      status: _selectedCustomer!.status,
      createdAt: _selectedCustomer!.createdAt,
      updatedAt: DateTime.now().toIso8601String(),
    );
    await ref.read(firestoreServiceProvider).saveCustomer(updatedCustomer);

    // Log Audit
    ref.read(appNotifierProvider.notifier).logAudit('Billing', 'Created Bill', billId);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bill #$billNumber generated successfully!')),
      );
      setState(() {
        _amountController.clear();
        _selectedCustomer = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final customersAsync = ref.watch(customersProvider);

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Quick Bill Counter',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 16),

            // Select Customer
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFF1F5F9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('1. Select Customer',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 10),
                  customersAsync.when(
                    data: (customers) {
                      return DropdownButtonFormField<Customer>(
                        value: _selectedCustomer,
                        hint: const Text('Choose customer...'),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                        ),
                        items: customers.map((c) {
                          return DropdownMenuItem(
                            value: c,
                            child: Text('${c.customerName} (Due: ₹${c.currentBalance})'),
                          );
                        }).toList(),
                        onChanged: (val) => setState(() => _selectedCustomer = val),
                      );
                    },
                    loading: () => const LinearProgressIndicator(),
                    error: (_, __) => const Text('Error loading customers'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Bill Amount Input
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFF1F5F9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('2. Enter Total Amount (₹)',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _amountController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w800),
                    decoration: InputDecoration(
                      prefixText: '₹ ',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            ElevatedButton.icon(
              onPressed: _createBill,
              icon: const Icon(Icons.print_rounded),
              label: const Text('Generate Bill & Print',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF15803D),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
