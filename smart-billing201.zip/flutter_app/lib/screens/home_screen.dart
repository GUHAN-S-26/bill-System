import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../models/models.dart';
import 'customers_screen.dart';
import 'billing_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';
import 'audit_logs_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _currentIndex = 0;

  void _showAddCustomerModal() {
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    final addressController = TextEditingController();
    final balanceController = TextEditingController(text: '0');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          top: 20,
          left: 20,
          right: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Add New Customer',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Customer Name *',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Phone Number',
                prefixIcon: Icon(Icons.phone),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: addressController,
              decoration: const InputDecoration(
                labelText: 'Address',
                prefixIcon: Icon(Icons.location_on),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: balanceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Opening Balance (₹)',
                prefixIcon: Icon(Icons.account_balance_wallet),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF15803D),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () {
                final name = nameController.text.trim();
                if (name.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter customer name')),
                  );
                  return;
                }

                final id = 'CUST-${DateTime.now().millisecondsSinceEpoch}';
                final openBal = double.tryParse(balanceController.text) ?? 0;

                final newCustomer = Customer(
                  customerId: id,
                  customerName: name,
                  phone: phoneController.text.trim(),
                  address: addressController.text.trim(),
                  groupId: 'grp-general',
                  openingBalance: openBal,
                  currentBalance: openBal,
                  status: 'active',
                  createdAt: DateTime.now().toIso8601String(),
                  updatedAt: DateTime.now().toIso8601String(),
                );

                ref.read(firestoreServiceProvider).saveCustomer(newCustomer);
                ref.read(appNotifierProvider.notifier).logAudit(
                      'Customers',
                      'Created Customer',
                      id,
                    );

                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Customer "$name" added successfully!')),
                );
              },
              child: const Text('Save Customer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  void _showCreateBillModal(List<Customer> customers) {
    String? selectedCustomerId = customers.isNotEmpty ? customers.first.customerId : null;
    final amountController = TextEditingController();
    final notesController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Create Quick Bill',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (customers.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text('No customers found. Please add a customer first.', style: TextStyle(color: Colors.red)),
                )
              else
                DropdownButtonFormField<String>(
                  value: selectedCustomerId,
                  decoration: const InputDecoration(
                    labelText: 'Select Customer *',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(),
                  ),
                  items: customers
                      .map((c) => DropdownMenuItem(
                            value: c.customerId,
                            child: Text('${c.customerName} (${c.phone.isNotEmpty ? c.phone : "No phone"})'),
                          ))
                      .toList(),
                  onChanged: (val) => setModalState(() => selectedCustomerId = val),
                ),
              const SizedBox(height: 12),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Bill Amount (₹) *',
                  prefixIcon: Icon(Icons.currency_rupee),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: notesController,
                decoration: const InputDecoration(
                  labelText: 'Notes / Description',
                  prefixIcon: Icon(Icons.notes),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF15803D),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () async {
                  if (selectedCustomerId == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please select a customer')),
                    );
                    return;
                  }
                  final amount = double.tryParse(amountController.text) ?? 0;
                  if (amount <= 0) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please enter a valid bill amount')),
                    );
                    return;
                  }

                  final customer = customers.firstWhere((c) => c.customerId == selectedCustomerId);
                  final billId = 'BIL-${DateTime.now().millisecondsSinceEpoch}';
                  final billNumber = '${DateTime.now().millisecondsSinceEpoch}'.substring(6);

                  final bill = Bill(
                    billId: billId,
                    billNumber: billNumber,
                    customerId: customer.customerId,
                    customerName: customer.customerName,
                    items: [
                      BillItem(
                        id: '1',
                        name: 'Retail Goods',
                        quantity: 1,
                        rate: amount,
                        total: amount,
                      )
                    ],
                    subtotal: amount,
                    paidAmount: 0,
                    balance: amount,
                    paymentStatus: 'Pending',
                    billDate: DateTime.now().toIso8601String(),
                    notes: notesController.text.trim().isEmpty ? 'Quick Bill' : notesController.text.trim(),
                  );

                  await ref.read(firestoreServiceProvider).saveBill(bill);

                  final updatedCustomer = Customer(
                    customerId: customer.customerId,
                    customerName: customer.customerName,
                    phone: customer.phone,
                    address: customer.address,
                    groupId: customer.groupId,
                    openingBalance: customer.openingBalance,
                    currentBalance: customer.currentBalance + amount,
                    status: customer.status,
                    createdAt: customer.createdAt,
                    updatedAt: DateTime.now().toIso8601String(),
                  );
                  await ref.read(firestoreServiceProvider).saveCustomer(updatedCustomer);
                  ref.read(appNotifierProvider.notifier).logAudit('Billing', 'Created Bill', billId);

                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Bill #$billNumber created successfully!')),
                    );
                  }
                },
                child: const Text('Generate Bill', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showReceivePaymentModal(List<Customer> customers) {
    String? selectedCustomerId = customers.isNotEmpty ? customers.first.customerId : null;
    final amountController = TextEditingController();
    String selectedMethod = 'UPI';
    final notesController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Receive Payment',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (customers.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text('No customers found.', style: TextStyle(color: Colors.red)),
                )
              else
                DropdownButtonFormField<String>(
                  value: selectedCustomerId,
                  decoration: const InputDecoration(
                    labelText: 'Select Customer *',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(),
                  ),
                  items: customers
                      .map((c) => DropdownMenuItem(
                            value: c.customerId,
                            child: Text('${c.customerName} (Due: ₹${c.currentBalance.toStringAsFixed(2)})'),
                          ))
                      .toList(),
                  onChanged: (val) => setModalState(() => selectedCustomerId = val),
                ),
              const SizedBox(height: 12),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Payment Amount (₹) *',
                  prefixIcon: Icon(Icons.currency_rupee),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: selectedMethod,
                decoration: const InputDecoration(
                  labelText: 'Payment Mode',
                  prefixIcon: Icon(Icons.payment),
                  border: OutlineInputBorder(),
                ),
                items: ['UPI', 'Cash', 'Card', 'NetBanking']
                    .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) setModalState(() => selectedMethod = val);
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: notesController,
                decoration: const InputDecoration(
                  labelText: 'Notes / Ref No.',
                  prefixIcon: Icon(Icons.notes),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0284C7),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () async {
                  if (selectedCustomerId == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please select a customer')),
                    );
                    return;
                  }
                  final amount = double.tryParse(amountController.text) ?? 0;
                  if (amount <= 0) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please enter a valid amount')),
                    );
                    return;
                  }

                  final customer = customers.firstWhere((c) => c.customerId == selectedCustomerId);
                  final paymentId = 'PAY-${DateTime.now().millisecondsSinceEpoch}';
                  final paymentNumber = 'REC-${'${DateTime.now().millisecondsSinceEpoch}'.substring(6)}';

                  final payment = Payment(
                    paymentId: paymentId,
                    paymentNumber: paymentNumber,
                    customerId: customer.customerId,
                    customerName: customer.customerName,
                    amount: amount,
                    paymentMethod: selectedMethod,
                    paymentDate: DateTime.now().toIso8601String(),
                    notes: notesController.text.trim().isEmpty ? 'Direct Collection' : notesController.text.trim(),
                  );

                  await ref.read(firestoreServiceProvider).savePayment(payment);

                  final newBalance = customer.currentBalance - amount;
                  final updatedCustomer = Customer(
                    customerId: customer.customerId,
                    customerName: customer.customerName,
                    phone: customer.phone,
                    address: customer.address,
                    groupId: customer.groupId,
                    openingBalance: customer.openingBalance,
                    currentBalance: newBalance,
                    status: customer.status,
                    createdAt: customer.createdAt,
                    updatedAt: DateTime.now().toIso8601String(),
                  );
                  await ref.read(firestoreServiceProvider).saveCustomer(updatedCustomer);
                  ref.read(appNotifierProvider.notifier).logAudit('Payments', 'Recorded Payment', paymentId);

                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Payment ₹${amount.toStringAsFixed(2)} recorded successfully!')),
                    );
                  }
                },
                child: const Text('Record Payment', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showQuickActionsModal(List<Customer> customers) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Quick Actions',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xFFDCFCE7), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.receipt_long_rounded, color: Color(0xFF15803D)),
              ),
              title: const Text('Create Bill', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Generate new customer invoice'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.pop(context);
                _showCreateBillModal(customers);
              },
            ),
            const Divider(),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xFFE0F2FE), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.payments_rounded, color: Color(0xFF0284C7)),
              ),
              title: const Text('Receive Payment', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Record incoming customer payment'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.pop(context);
                _showReceivePaymentModal(customers);
              },
            ),
            const Divider(),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xFFF3E8FF), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.person_add_rounded, color: Color(0xFF7C3AED)),
              ),
              title: const Text('Add Customer', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Add new customer to ledger'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.pop(context);
                _showAddCustomerModal();
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final owner = ref.watch(currentOwnerProvider);
    final settingsAsync = ref.watch(shopSettingsProvider);
    final billsAsync = ref.watch(billsProvider);
    final customersAsync = ref.watch(customersProvider);
    final paymentsAsync = ref.watch(paymentsProvider);

    final shopName = settingsAsync.value?.shopName ?? 'Shankar Shop';
    final customersList = customersAsync.value ?? [];

    final pages = [
      _buildDashboardView(context, shopName, owner, billsAsync, customersAsync, paymentsAsync),
      const CustomersScreen(),
      const BillingScreen(),
      const ReportsScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              shopName,
              style: const TextStyle(
                color: Color(0xFF0F172A),
                fontWeight: FontWeight.w800,
                fontSize: 18,
              ),
            ),
            Row(
              children: [
                Text(
                  'Logged in as ${owner?.displayName ?? "Owner"}',
                  style: const TextStyle(color: Color(0xFF64748B), fontSize: 12),
                ),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFDCFCE7),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text(
                    'OWNER',
                    style: TextStyle(
                      color: Color(0xFF15803D),
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFF1F5F9),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: const [
                Icon(Icons.cloud_done_rounded, color: Color(0xFF16A34A), size: 16),
                SizedBox(width: 4),
                Text(
                  'Online',
                  style: TextStyle(
                    color: Color(0xFF15803D),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.history, color: Color(0xFF64748B)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AuditLogsScreen()),
              );
            },
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showQuickActionsModal(customersList),
        backgroundColor: const Color(0xFF15803D),
        elevation: 4,
        child: const Icon(Icons.add, color: Colors.white, size: 28),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        selectedItemColor: const Color(0xFF15803D),
        unselectedItemColor: const Color(0xFF94A3B8),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_filled), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.people_alt_rounded), label: 'Customers'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long_rounded), label: 'Billing'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart_rounded), label: 'Reports'),
          BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _buildDashboardView(
      BuildContext context,
      String shopName,
      owner,
      billsAsync,
      customersAsync,
      paymentsAsync) {
    final bills = billsAsync.value ?? [];
    final customers = customersAsync.value ?? [];
    final payments = paymentsAsync.value ?? [];

    final totalSales = bills.fold<double>(0.0, (sum, b) => sum + b.subtotal);
    final totalCollection = payments.fold<double>(0.0, (sum, p) => sum + p.amount);
    final totalPending = customers.fold<double>(0.0, (sum, c) => sum + c.currentBalance);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Stat Cards Grid
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.35,
            children: [
              _statCard("Today's Sales", '₹${totalSales.toStringAsFixed(2)}',
                  Icons.shopping_bag_outlined, const Color(0xFF15803D)),
              _statCard("Today's Collection", '₹${totalCollection.toStringAsFixed(2)}',
                  Icons.account_balance_wallet_outlined, const Color(0xFF0284C7)),
              _statCard('Total Pending', '₹${totalPending.toStringAsFixed(2)}',
                  Icons.pending_actions_rounded, const Color(0xFFEA580C)),
              _statCard('Total Customers', '${customers.length}',
                  Icons.people_outline_rounded, const Color(0xFF7C3AED)),
            ],
          ),
          const SizedBox(height: 20),

          // Prominent Quick Actions Row
          const Text(
            'Quick Actions',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: Color(0xFF0F172A),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _quickActionButton(
                  label: 'Create Bill',
                  icon: Icons.receipt_long_rounded,
                  color: const Color(0xFF15803D),
                  bgColor: const Color(0xFFDCFCE7),
                  onTap: () => _showCreateBillModal(customers),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _quickActionButton(
                  label: 'Receive Payment',
                  icon: Icons.payments_rounded,
                  color: const Color(0xFF0284C7),
                  bgColor: const Color(0xFFE0F2FE),
                  onTap: () => _showReceivePaymentModal(customers),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _quickActionButton(
                  label: 'Add Customer',
                  icon: Icons.person_add_rounded,
                  color: const Color(0xFF7C3AED),
                  bgColor: const Color(0xFFF3E8FF),
                  onTap: _showAddCustomerModal,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Recent Transactions Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Recent Bills',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF0F172A),
                ),
              ),
              TextButton(
                onPressed: () => _showCreateBillModal(customers),
                child: const Text('+ Create Bill',
                    style: TextStyle(color: Color(0xFF15803D), fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 8),

          if (bills.isEmpty)
            Container(
              padding: const EdgeInsets.all(32),
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Center(
                child: Text('No bills created yet.',
                    style: TextStyle(color: Color(0xFF94A3B8))),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: bills.take(5).length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final bill = bills[index];
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFF1F5F9)),
                  ),
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      bill.customerName,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                    subtitle: Text('Bill #${bill.billNumber}'),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '₹${bill.subtotal.toStringAsFixed(2)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 14),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: bill.paymentStatus == 'Paid'
                                ? const Color(0xFFDCFCE7)
                                : const Color(0xFFFFEDD5),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            bill.paymentStatus,
                            style: TextStyle(
                              color: bill.paymentStatus == 'Paid'
                                  ? const Color(0xFF15803D)
                                  : const Color(0xFFC2410C),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _quickActionButton({
    required String label,
    required IconData icon,
    required Color color,
    required Color bgColor,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      elevation: 0,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFE2E8F0)),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: bgColor,
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF64748B),
                  ),
                ),
              ),
              Icon(icon, color: color, size: 20),
            ],
          ),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0F172A),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

