import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';

class ReportsScreen extends ConsumerWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final billsAsync = ref.watch(billsProvider);
    final paymentsAsync = ref.watch(paymentsProvider);
    final customersAsync = ref.watch(customersProvider);

    final bills = billsAsync.value ?? [];
    final payments = paymentsAsync.value ?? [];
    final customers = customersAsync.value ?? [];

    final totalSales = bills.fold<double>(0.0, (sum, b) => sum + b.subtotal);
    final totalCollections = payments.fold<double>(0.0, (sum, p) => sum + p.amount);
    final totalPending = customers.fold<double>(0.0, (sum, c) => sum + c.currentBalance);

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Business & Credit Analytics',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 16),

            _reportRow('Total Sales Ledger', '₹${totalSales.toStringAsFixed(2)}',
                Icons.trending_up_rounded, Colors.green),
            const SizedBox(height: 10),
            _reportRow('Total Payments Received', '₹${totalCollections.toStringAsFixed(2)}',
                Icons.account_balance_rounded, Colors.blue),
            const SizedBox(height: 10),
            _reportRow('Total Outstanding Credit', '₹${totalPending.toStringAsFixed(2)}',
                Icons.warning_amber_rounded, Colors.orange),
            const SizedBox(height: 24),

            const Text(
              'Export & Backup Reports',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),

            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
                title: const Text('Download Sales Statement PDF'),
                trailing: const Icon(Icons.download_rounded),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Generating PDF report...')),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                leading: const Icon(Icons.table_chart_rounded, color: Colors.green),
                title: const Text('Backup Data to Google Sheets'),
                trailing: const Icon(Icons.cloud_upload_rounded),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Data synced to Google Sheets backup!')),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _reportRow(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: color.withOpacity(0.1),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                Text(value,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
