# Smart Billing System - Flutter Application

The **Smart Billing System** is an offline-first Flutter application designed for single-shop billing, customer credit management, payment collection, and audit tracking on **Android** and **Windows Desktop**.

---

## 🚀 Features & Architecture

- **Offline-First Architecture**: Powered by Cloud Firestore offline persistence and local state caching.
- **Cross-Platform Support**: Built natively for **Android** and **Windows Desktop**.
- **State Management**: Uses `flutter_riverpod` (v2) for reactive, reliable app state across screens.
- **Firebase Authentication & Firestore**: Full account authentication and audit logging for shop owners:
  - **Venkatesh** (`venkatesh@shankarshop.com`)
  - **Priya** (`priya@shankarshop.com`)
  - **Deepika** (`deepika@shankarshop.com`)
- **Active Owner Session Sync**: Automatically syncs active owner profile (Name, Email, Role, Login Time, Last Active Time) to Firestore.
- **Audit Log Trail**: Logs every action (Login, Logout, Updated Shop Settings, Created/Updated/Deleted Customer, Created/Updated/Deleted Bill, Received Payment) to Cloud Firestore with filters for Owner & Module.

---

## 🛠️ Folder Structure

```
flutter_app/
├── pubspec.yaml
└── lib/
    ├── main.dart                   # Flutter App Entry Point
    ├── models/
    │   └── models.dart             # Customer, Bill, Payment, ShopSettings, AuditLog, OwnerProfile
    ├── services/
    │   ├── auth_service.dart       # Firebase Auth & Owner Passcode Login
    │   └── firestore_service.dart  # Firestore streams, offline persistence, session & audit log sync
    ├── providers/
    │   └── app_providers.dart      # Riverpod Providers & Audit Logger
    └── screens/
        ├── login_screen.dart       # Owner Selection & Passcode Login Screen
        ├── home_screen.dart        # Dashboard, Daily Sales, Collections & Recent Bills
        ├── customers_screen.dart   # Customer Directory, Search & Credit Balance Tracking
        ├── billing_screen.dart     # Quick 20-second Bill Counter
        ├── reports_screen.dart     # Business Ledger Analytics & PDF Statements
        ├── settings_screen.dart    # Shop Configuration, Active Owner Profile & Logout
        └── audit_logs_screen.dart  # Filterable Audit Log Trail
```

---

## 📱 How to Run on Android

1. Ensure Flutter SDK (>=3.0.0) and Android Studio / SDK are installed.
2. Navigate to the Flutter directory:
   ```bash
   cd flutter_app
   ```
3. Install dependencies:
   ```bash
   flutter pub get
   ```
4. Connect an Android device or launch an emulator.
5. Run the application:
   ```bash
   flutter run -d android
   ```
6. Build release APK or App Bundle:
   ```bash
   flutter build apk --release
   ```

---

## 💻 How to Run on Windows Desktop

1. Ensure Desktop support is enabled in Flutter:
   ```bash
   flutter config --enable-windows-desktop
   ```
2. Navigate to the Flutter directory:
   ```bash
   cd flutter_app
   ```
3. Run the application on Windows:
   ```bash
   flutter run -d windows
   ```
4. Build Windows executable:
   ```bash
   flutter build windows --release
   ```

---

## 🔐 Credentials & Default Passcode

- Default Passcode for all test owner accounts (**Venkatesh**, **Priya**, **Deepika**): `2003`.
